// Castle layouts built from interlocking balsa planks (Jenga-style), guards and a flag.
// Coordinates relative to castle centre on the ground; +x = away from the launcher.
const EPS = 0.0004;
const PL = 0.06, PW = 0.02; // plank half length / half width (12 cm x 4 cm x 4 cm)

function tower(out, cx, cz, layers, { half = PL, look = 'stone', roof = true } = {}) {
  const off = half - PW;
  let y = 0;
  for (let i = 0; i < layers; i++) {
    const yc = y + PW + EPS;
    if (i % 2 === 0) {
      out.push({ kind: 'block', he: [half, PW, PW], p: [cx, yc, cz - off], look });
      out.push({ kind: 'block', he: [half, PW, PW], p: [cx, yc, cz + off], look });
    } else {
      out.push({ kind: 'block', he: [PW, PW, half], p: [cx - off, yc, cz], look });
      out.push({ kind: 'block', he: [PW, PW, half], p: [cx + off, yc, cz], look });
    }
    y += 2 * PW + EPS;
  }
  if (roof) {
    const along = layers % 2 === 0; // alternate again
    for (const o of [-off, 0, off]) {
      out.push(along
        ? { kind: 'block', he: [half, 0.01, PW], p: [cx, y + 0.01 + EPS, cz + o], look: 'roof' }
        : { kind: 'block', he: [PW, 0.01, half], p: [cx + o, y + 0.01 + EPS, cz], look: 'roof' });
    }
    y += 0.02 + EPS;
    // crenellations
    for (const [dx, dz] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
      out.push({ kind: 'block', he: [0.012, 0.015, 0.012], p: [cx + dx * (half - 0.012), y + 0.015 + EPS, cz + dz * (half - 0.012)], look });
    }
  }
  return y;
}

function wall(out, cx, z0, z1, layers) {
  const h = (z1 - z0) / 4;
  let y = 0;
  for (let i = 0; i < layers; i++) {
    const yc = y + PW + EPS;
    if (i % 2 === 0) {
      out.push({ kind: 'block', he: [PW, PW, h - EPS], p: [cx, yc, z0 + h], look: 'stone' });
      out.push({ kind: 'block', he: [PW, PW, h - EPS], p: [cx, yc, z0 + 3 * h], look: 'stone' });
    } else {
      out.push({ kind: 'block', he: [PW, PW, h / 2 - EPS], p: [cx, yc, z0 + h / 2], look: 'stone' });
      out.push({ kind: 'block', he: [PW, PW, h - EPS], p: [cx, yc, z0 + 2 * h], look: 'stone' });
      out.push({ kind: 'block', he: [PW, PW, h / 2 - EPS], p: [cx, yc, z1 - h / 2], look: 'stone' });
    }
    y += 2 * PW + EPS;
  }
  return y;
}

export const CASTLES = {
  outpost: {
    label: 'Outpost', blurb: 'One tall watchtower. Knock it down!',
    build() {
      const o = [];
      const top = tower(o, 0, 0, 10);
      o.push({ kind: 'guard', p: [0, top + 0.0005, -0.03] });
      o.push({ kind: 'flag', p: [0, top, 0.03] });
      // palisade
      for (let i = -2; i <= 2; i++) o.push({ kind: 'block', he: [0.008, 0.04, 0.025], p: [-0.16, 0.04 + EPS, i * 0.052], look: 'wood' });
      return o;
    },
  },
  gatehouse: {
    label: 'Gatehouse', blurb: 'Twin towers and a wall. Two guards and a banner.',
    build() {
      const o = [];
      const t1 = tower(o, 0, -0.2, 8);
      const t2 = tower(o, 0, 0.2, 8);
      const wy = wall(o, 0, -0.14, 0.14, 6);
      o.push({ kind: 'guard', p: [0, t1 + 0.0005, -0.2] });
      o.push({ kind: 'guard', p: [0, t2 + 0.0005, 0.2] });
      o.push({ kind: 'flag', p: [0, wy, 0] });
      return o;
    },
  },
  fortress: {
    label: 'Fortress', blurb: 'Gatehouse plus a tall keep behind it. Ultimate siege.',
    build() {
      const o = [];
      const t1 = tower(o, 0, -0.2, 7);
      const t2 = tower(o, 0, 0.2, 7);
      wall(o, 0, -0.14, 0.14, 5);
      const k = tower(o, 0.36, 0, 11, { half: 0.08 });
      o.push({ kind: 'guard', p: [0, t1 + 0.0005, -0.2] });
      o.push({ kind: 'guard', p: [0, t2 + 0.0005, 0.2] });
      o.push({ kind: 'guard', p: [0.36, k + 0.0005, -0.035] });
      o.push({ kind: 'flag', p: [0.36, k, 0.035] });
      return o;
    },
  },
};
