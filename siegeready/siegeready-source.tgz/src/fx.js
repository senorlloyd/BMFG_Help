// Visual helpers: procedural textures, sky, particles, label sprites.
import * as THREE from 'three';

function canvas(w, h) { const c = document.createElement('canvas'); c.width = w; c.height = h; return [c, c.getContext('2d')]; }

export function grassTexture() {
  const [c, g] = canvas(512, 512);
  g.fillStyle = '#3f6b2a'; g.fillRect(0, 0, 512, 512);
  for (let i = 0; i < 9000; i++) {
    const x = Math.random() * 512, y = Math.random() * 512;
    const l = 25 + Math.random() * 25, h = 85 + Math.random() * 30;
    g.strokeStyle = `hsl(${h},${40 + Math.random() * 25}%,${l}%)`;
    g.lineWidth = 1 + Math.random();
    g.beginPath(); g.moveTo(x, y); g.lineTo(x + (Math.random() - 0.5) * 4, y - 3 - Math.random() * 6); g.stroke();
  }
  const t = new THREE.CanvasTexture(c);
  t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 8;
  return t;
}

export function woodTexture(base = '#d8b07a') {
  const [c, g] = canvas(256, 256);
  g.fillStyle = base; g.fillRect(0, 0, 256, 256);
  for (let i = 0; i < 70; i++) {
    const y = Math.random() * 256;
    g.strokeStyle = `rgba(90,55,20,${0.05 + Math.random() * 0.12})`;
    g.lineWidth = 1 + Math.random() * 2;
    g.beginPath(); g.moveTo(0, y);
    for (let x = 0; x <= 256; x += 16) g.lineTo(x, y + Math.sin(x / 40 + i) * 3);
    g.stroke();
  }
  const t = new THREE.CanvasTexture(c); t.wrapS = t.wrapT = THREE.RepeatWrapping; t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function stoneTexture() {
  const [c, g] = canvas(128, 128);
  g.fillStyle = '#8d8a83'; g.fillRect(0, 0, 128, 128);
  for (let i = 0; i < 1400; i++) {
    const v = 100 + Math.random() * 80;
    g.fillStyle = `rgba(${v},${v - 4},${v - 10},0.35)`;
    g.fillRect(Math.random() * 128, Math.random() * 128, 2 + Math.random() * 3, 2 + Math.random() * 3);
  }
  g.strokeStyle = 'rgba(40,38,35,0.55)'; g.lineWidth = 3; g.strokeRect(1.5, 1.5, 125, 125);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

export function softDot() {
  const [c, g] = canvas(64, 64);
  const gr = g.createRadialGradient(32, 32, 0, 32, 32, 32);
  gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.35, 'rgba(255,255,255,0.7)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  g.fillStyle = gr; g.fillRect(0, 0, 64, 64);
  return new THREE.CanvasTexture(c);
}

export function makeSky() {
  const geo = new THREE.SphereGeometry(400, 32, 16);
  const mat = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false, fog: false,
    uniforms: {
      top: { value: new THREE.Color('#0f1d3d') }, mid: { value: new THREE.Color('#d9643a') },
      bot: { value: new THREE.Color('#2a1c25') }, sunDir: { value: new THREE.Vector3(-0.6, 0.12, -0.8).normalize() },
    },
    vertexShader: 'varying vec3 vP; void main(){ vP = normalize(position); gl_Position = projectionMatrix*modelViewMatrix*vec4(position,1.0);} ',
    fragmentShader: `uniform vec3 top, mid, bot, sunDir; varying vec3 vP;
      void main(){ float h = vP.y; vec3 c = h>0.0 ? mix(mid, top, pow(clamp(h*1.6,0.0,1.0),0.6)) : mix(mid, bot, clamp(-h*4.0,0.0,1.0));
        float s = max(dot(vP, sunDir), 0.0); c += vec3(1.0,0.75,0.4)*pow(s, 180.0)*1.6 + vec3(1.0,0.5,0.2)*pow(s, 8.0)*0.35;
        gl_FragColor = vec4(c,1.0); }`,
  });
  return new THREE.Mesh(geo, mat);
}

export function mountains() {
  const g = new THREE.Group();
  const mat = new THREE.MeshBasicMaterial({ color: 0x2a2433, fog: false });
  const mat2 = new THREE.MeshBasicMaterial({ color: 0x3b2d3a, fog: false });
  for (let i = 0; i < 26; i++) {
    const a = (i / 26) * Math.PI * 2 + Math.random() * 0.2;
    const r = 260 + Math.random() * 60, h = 25 + Math.random() * 45;
    const m = new THREE.Mesh(new THREE.ConeGeometry(30 + Math.random() * 40, h, 5), i % 2 ? mat : mat2);
    m.position.set(Math.cos(a) * r, h / 2 - 4, Math.sin(a) * r);
    m.rotation.y = Math.random() * 6;
    g.add(m);
  }
  return g;
}

export class Particles {
  constructor(max, { additive = true, texture, scale = 1 } = {}) {
    this.max = max; this.n = 0;
    this.pos = new Float32Array(max * 3); this.vel = new Float32Array(max * 3);
    this.col = new Float32Array(max * 3); this.size = new Float32Array(max); this.alpha = new Float32Array(max);
    this.life = new Float32Array(max); this.age = new Float32Array(max); this.grow = new Float32Array(max);
    this.s0 = new Float32Array(max); this.a0 = new Float32Array(max); this.grav = new Float32Array(max); this.drag = new Float32Array(max);
    this.c0 = new Float32Array(max * 3); this.c1 = new Float32Array(max * 3);
    const geo = new THREE.BufferGeometry();
    geo.setAttribute('position', new THREE.BufferAttribute(this.pos, 3));
    geo.setAttribute('color', new THREE.BufferAttribute(this.col, 3));
    geo.setAttribute('size', new THREE.BufferAttribute(this.size, 1));
    geo.setAttribute('alpha', new THREE.BufferAttribute(this.alpha, 1));
    this.mat = new THREE.ShaderMaterial({
      uniforms: { map: { value: texture }, scale: { value: 400 * scale } },
      vertexShader: `attribute float size; attribute float alpha; attribute vec3 color; varying vec3 vC; varying float vA;
        uniform float scale; void main(){ vC=color; vA=alpha; vec4 mv = modelViewMatrix*vec4(position,1.0);
        gl_PointSize = size*scale/max(-mv.z,0.01); gl_Position = projectionMatrix*mv; }`,
      fragmentShader: `uniform sampler2D map; varying vec3 vC; varying float vA;
        void main(){ vec4 t = texture2D(map, gl_PointCoord); gl_FragColor = vec4(vC*t.rgb, t.a*vA); if(gl_FragColor.a<0.01) discard; }`,
      transparent: true, depthWrite: false, blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
    });
    this.points = new THREE.Points(geo, this.mat);
    this.points.frustumCulled = false;
    this.geo = geo;
  }
  emit(p, v, { life = 0.6, size = 0.03, grow = 1, alpha = 1, c0 = [1, 0.8, 0.3], c1 = [1, 0.2, 0], grav = 0, drag = 0 } = {}) {
    let i = this.n < this.max ? this.n++ : Math.floor(Math.random() * this.max);
    this.pos[i * 3] = p.x; this.pos[i * 3 + 1] = p.y; this.pos[i * 3 + 2] = p.z;
    this.vel[i * 3] = v.x; this.vel[i * 3 + 1] = v.y; this.vel[i * 3 + 2] = v.z;
    this.life[i] = life; this.age[i] = 0; this.s0[i] = size; this.grow[i] = grow; this.a0[i] = alpha;
    this.grav[i] = grav; this.drag[i] = drag;
    this.c0.set(c0, i * 3); this.c1.set(c1, i * 3);
  }
  update(dt) {
    let j = 0;
    for (let i = 0; i < this.n; i++) {
      this.age[i] += dt;
      if (this.age[i] >= this.life[i]) continue;
      if (j !== i) this.copy(i, j);
      const k = this.age[j] / this.life[j];
      const d = Math.max(0, 1 - this.drag[j] * dt);
      this.vel[j * 3] *= d; this.vel[j * 3 + 1] = this.vel[j * 3 + 1] * d - this.grav[j] * dt; this.vel[j * 3 + 2] *= d;
      this.pos[j * 3] += this.vel[j * 3] * dt; this.pos[j * 3 + 1] += this.vel[j * 3 + 1] * dt; this.pos[j * 3 + 2] += this.vel[j * 3 + 2] * dt;
      this.size[j] = this.s0[j] * (1 + (this.grow[j] - 1) * k);
      this.alpha[j] = this.a0[j] * (k < 0.15 ? k / 0.15 : 1 - (k - 0.15) / 0.85);
      for (let c = 0; c < 3; c++) this.col[j * 3 + c] = this.c0[j * 3 + c] + (this.c1[j * 3 + c] - this.c0[j * 3 + c]) * k;
      j++;
    }
    this.n = j;
    this.geo.setDrawRange(0, this.n);
    for (const a of ['position', 'color', 'size', 'alpha']) this.geo.attributes[a].needsUpdate = true;
  }
  copy(i, j) {
    for (const arr of [this.pos, this.vel, this.col, this.c0, this.c1]) { arr[j * 3] = arr[i * 3]; arr[j * 3 + 1] = arr[i * 3 + 1]; arr[j * 3 + 2] = arr[i * 3 + 2]; }
    for (const arr of [this.size, this.alpha, this.life, this.age, this.grow, this.s0, this.a0, this.grav, this.drag]) arr[j] = arr[i];
  }
  clear() { this.n = 0; this.geo.setDrawRange(0, 0); }
}

// Flat text label lying on the ground (or a billboard sprite)
export function textPlane(text, { w = 0.6, h = 0.2, color = '#fff', bg = null, font = 'bold 72px Inter, sans-serif', sub = null } = {}) {
  const [c, g] = canvas(512, Math.round((512 * h) / w));
  if (bg) { g.fillStyle = bg; g.fillRect(0, 0, c.width, c.height); }
  g.fillStyle = color; g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = font;
  g.fillText(text, c.width / 2, sub ? c.height * 0.4 : c.height / 2);
  if (sub) { g.font = '600 40px Inter, sans-serif'; g.globalAlpha = 0.8; g.fillText(sub, c.width / 2, c.height * 0.8); }
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), new THREE.MeshBasicMaterial({ map: t, transparent: true, depthWrite: false }));
  return m;
}

export function sprite(text, { scale = 0.25, color = '#fff', bg = 'rgba(20,14,10,0.78)' } = {}) {
  const [c, g] = canvas(512, 160);
  g.fillStyle = bg; const r = 40;
  g.beginPath(); g.roundRect(8, 8, 496, 144, r); g.fill();
  g.strokeStyle = 'rgba(255,190,90,0.9)'; g.lineWidth = 6; g.stroke();
  g.fillStyle = color; g.font = 'bold 64px Inter, sans-serif'; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.fillText(text, 256, 84);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace;
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: t, depthTest: false }));
  s.scale.set(scale, (scale * 160) / 512, 1); s.renderOrder = 10;
  return s;
}
