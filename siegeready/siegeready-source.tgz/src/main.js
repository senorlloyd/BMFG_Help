import * as THREE from 'three';
import { OrbitControls } from 'three/examples/jsm/controls/OrbitControls.js';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { STLLoader } from 'three/examples/jsm/loaders/STLLoader.js';
import { GLTFExporter } from 'three/examples/jsm/exporters/GLTFExporter.js';
import { RoomEnvironment } from 'three/examples/jsm/environments/RoomEnvironment.js';
import RAPIER from '@dimforge/rapier3d-compat';
import {
  MATERIALS, effectiveDensity, geomMoments, buildRig, simulateLaunch, bandLengths,
  MARBLE_R, MARBLE_M, IN, G,
} from './physics.js';
import { sampleCatapult, sampleTrebuchet } from './samples.js';
import { CASTLES } from './castle.js';
import { grassTexture, woodTexture, stoneTexture, softDot, makeSky, mountains, Particles, textPlane, sprite } from './fx.js';

const $ = (s) => document.querySelector(s);
const $$ = (s) => [...document.querySelectorAll(s)];
const FT = 0.3048;
const DT = 1 / 600;
const POST_CAP = 8; // seconds of world sim after release per shot

// ---------- formatting ----------
function ftIn(m) {
  const totalIn = m / IN;
  const sign = totalIn < 0 ? '-' : '';
  const a = Math.abs(totalIn);
  let ft = Math.floor(a / 12), inch = Math.round(a - ft * 12);
  if (inch === 12) { ft++; inch = 0; }
  return `${sign}${ft}′ ${inch}″`;
}
const mph = (ms) => ms * 2.23694;
const deg = (r) => (r * 180) / Math.PI;

// ---------- renderer / scene ----------
const canvas = $('#c');
const renderer = new THREE.WebGLRenderer({ canvas, antialias: true });
renderer.setPixelRatio(Math.min(devicePixelRatio, 2));
renderer.shadowMap.enabled = true;
renderer.shadowMap.type = THREE.PCFShadowMap;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.05;
const scene = new THREE.Scene();
scene.fog = new THREE.FogExp2(0x3a2a2c, 0.022);
const camera = new THREE.PerspectiveCamera(45, 1, 0.01, 900);
camera.position.set(0.5, 0.35, 0.6);
const controls = new OrbitControls(camera, canvas);
controls.enableDamping = true; controls.target.set(0, 0.1, 0);
controls.maxPolarAngle = Math.PI * 0.495; controls.minDistance = 0.12; controls.maxDistance = 25;

scene.environment = new THREE.PMREMGenerator(renderer).fromScene(new RoomEnvironment(), 0.04).texture;
scene.environmentIntensity = 0.35;
scene.add(makeSky());
scene.add(mountains());
const hemi = new THREE.HemisphereLight(0xffd2a8, 0x2c3a1c, 1.1); scene.add(hemi);
const sun = new THREE.DirectionalLight(0xffc48a, 2.6);
sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
sun.shadow.camera.left = sun.shadow.camera.bottom = -1.2; sun.shadow.camera.right = sun.shadow.camera.top = 1.2;
sun.shadow.camera.near = 0.1; sun.shadow.camera.far = 20; sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.01;
scene.add(sun, sun.target);
const SUN_OFF = new THREE.Vector3(-4, 3.2, -3);
function aimSun(focus, half = 1.2) {
  sun.position.copy(focus).add(SUN_OFF); sun.target.position.copy(focus);
  const c = sun.shadow.camera; if (c.right !== half) { c.left = c.bottom = -half; c.right = c.top = half; c.updateProjectionMatrix(); }
}

// ground
const grass = grassTexture(); grass.repeat.set(160, 160);
const ground = new THREE.Mesh(new THREE.PlaneGeometry(240, 240), new THREE.MeshStandardMaterial({ map: grass, roughness: 1 }));
ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true; scene.add(ground);

const fireTex = softDot();
const fire = new Particles(3500, { additive: true, texture: fireTex });
const smoke = new Particles(1200, { additive: false, texture: fireTex });
scene.add(smoke.points, fire.points);
const fireLight = new THREE.PointLight(0xff7a2a, 0, 3, 1.6); scene.add(fireLight);
const marbleLight = new THREE.PointLight(0xff8a3a, 0, 2.5, 1.5); scene.add(marbleLight);

// ---------- range ----------
const range = new THREE.Group(); scene.add(range);
const torches = [];
const labelJobs = [];
(function buildRange() {
  const dirt = new THREE.Mesh(new THREE.PlaneGeometry(14, 1.4), new THREE.MeshStandardMaterial({ color: 0x6b5338, roughness: 1, transparent: true, opacity: 0.55 }));
  dirt.rotation.x = -Math.PI / 2; dirt.position.set(6.8, 0.0008, 0); dirt.receiveShadow = true; range.add(dirt);
  const lineMat = new THREE.MeshBasicMaterial({ color: 0xffffff, transparent: true, opacity: 0.5 });
  for (let f = 0; f <= 44; f++) {
    const major = f % 5 === 0;
    const l = new THREE.Mesh(new THREE.PlaneGeometry(major ? 0.012 : 0.006, major ? 1.3 : 0.5), lineMat);
    l.rotation.x = -Math.PI / 2; l.position.set(f * FT, 0.0015, 0); range.add(l);
    if (major && f > 0) {
      for (const side of [-1, 1]) labelJobs.push(() => {
        const t = textPlane(`${f} ft`, { w: 0.5, h: 0.2, sub: `${(f * FT).toFixed(1)} m`, color: '#fff3d6' });
        t.rotation.x = -Math.PI / 2; t.rotation.z = Math.PI / 2;
        t.position.set(f * FT, 0.002, side * 0.9); range.add(t);
      });
    }
  }
  // torches
  const postMat = new THREE.MeshStandardMaterial({ color: 0x3b2614 });
  const runLabels = () => labelJobs.forEach((j) => j());
  (document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve()).then(runLabels, runLabels);
  for (const x of [1, 4, 7, 10]) for (const z of [-1.15, 1.15]) {
    const p = new THREE.Mesh(new THREE.CylinderGeometry(0.02, 0.025, 0.9, 8), postMat);
    p.position.set(x, 0.45, z); p.castShadow = true; range.add(p);
    torches.push(new THREE.Vector3(x, 0.93, z));
  }
})();

const rings = new THREE.Group(); scene.add(rings); rings.visible = false;
(function buildRings() {
  const radii = [24, 18, 12, 6, 3];
  const cols = [0xf4e9dc, 0xc0392b, 0xf4e9dc, 0xc0392b, 0xffd36b];
  radii.forEach((r, i) => {
    const m = new THREE.Mesh(new THREE.CircleGeometry(r * IN, 48), new THREE.MeshStandardMaterial({ color: cols[i], roughness: 0.9 }));
    m.rotation.x = -Math.PI / 2; m.position.y = 0.002 + i * 0.0004; m.receiveShadow = true; rings.add(m);
  });
})();

// ---------- launcher scene objects ----------
const launcherRoot = new THREE.Group(); launcherRoot.matrixAutoUpdate = false; scene.add(launcherRoot);
const baseGroup = new THREE.Group(), armGroup = new THREE.Group(), ghostGroup = new THREE.Group(), helperGroup = new THREE.Group();
armGroup.matrixAutoUpdate = false; ghostGroup.matrixAutoUpdate = false;
launcherRoot.add(baseGroup, armGroup, ghostGroup, helperGroup);
const armMarkers = new THREE.Group(); armGroup.add(armMarkers);

const marbleMat = new THREE.MeshPhysicalMaterial({ color: 0x4fb3ff, roughness: 0.05, metalness: 0, transmission: 0.2, clearcoat: 1, emissive: 0x000000 });
const marble = new THREE.Mesh(new THREE.SphereGeometry(MARBLE_R, 24, 16), marbleMat);
marble.castShadow = true; scene.add(marble);
const swirl = new THREE.Mesh(new THREE.TorusGeometry(MARBLE_R * 0.55, MARBLE_R * 0.18, 8, 24), new THREE.MeshStandardMaterial({ color: 0xffe066, emissive: 0x442200 }));
marble.add(swirl);

const bandMat = new THREE.MeshStandardMaterial({ color: 0xc89a5a, roughness: 0.7 });
const bandMeshes = [];
const slingMesh = new THREE.Mesh(new THREE.CylinderGeometry(0.0012, 0.0012, 1, 6), new THREE.MeshStandardMaterial({ color: 0x8a6a4a }));
const pouch = new THREE.Mesh(new THREE.SphereGeometry(0.011, 12, 8), new THREE.MeshStandardMaterial({ color: 0x5a3d26, roughness: 1 }));
pouch.scale.set(1, 0.5, 1); scene.add(slingMesh, pouch); slingMesh.visible = pouch.visible = false;

const cubeHelper = new THREE.LineSegments(new THREE.EdgesGeometry(new THREE.BoxGeometry(12 * IN, 12 * IN, 12 * IN)), new THREE.LineBasicMaterial({ color: 0x6fd38a, transparent: true, opacity: 0.6 }));
helperGroup.add(cubeHelper);
const pivotLine = new THREE.Mesh(new THREE.CylinderGeometry(0.0015, 0.0015, 0.16, 8), new THREE.MeshBasicMaterial({ color: 0x56c2ff, depthTest: false, transparent: true }));
pivotLine.renderOrder = 5; helperGroup.add(pivotLine);
const pivotDot = new THREE.Mesh(new THREE.SphereGeometry(0.005, 12, 8), new THREE.MeshBasicMaterial({ color: 0x56c2ff, depthTest: false, transparent: true }));
pivotDot.renderOrder = 5; helperGroup.add(pivotDot);

// ---------- app state ----------
const S = {
  L: null, // launcher { name, parts, pivot, axis, holder, cup, sling, bands, cockDeg, stopDeg, releaseDeg, friction, floorY }
  view: 'rig', tab: 'build', previewDeg: 0, sel: -1, pick: null, axisManual: false,
  mode: 'siege', castle: 'gatehouse', tgtFt: 15, ignite: true, slowmo: true, trail: true,
  phase: 'idle', shot: null, round: { n: 0, used: 0, score: 0, seed: 1, best: 0 },
  rig: null, sim: null, simKey: '', log: [], medals: new Set(), sound: true, importState: null,
};
try { S.log = JSON.parse(localStorage.getItem('siegeready.log') || '[]'); } catch { S.log = []; }
try { S.medals = new Set(JSON.parse(localStorage.getItem('siegeready.medals') || '[]')); } catch { /* */ }
function saveLocal() {
  try { localStorage.setItem('siegeready.log', JSON.stringify(S.log)); localStorage.setItem('siegeready.medals', JSON.stringify([...S.medals])); } catch { /* storage unavailable */ }
}

// ---------- materials for parts ----------
const woodTex = woodTexture();
function partMaterial(p) {
  const m = MATERIALS[p.material] || MATERIALS.plywood;
  const mat = new THREE.MeshStandardMaterial({
    color: m.color, roughness: m.metal ? 0.35 : 0.75, metalness: m.metal ? 0.85 : 0,
    transparent: p.role === 'ignore', opacity: p.role === 'ignore' ? 0.18 : 1, side: THREE.DoubleSide,
  });
  if (p.role === 'arm' && !m.metal) mat.emissive = new THREE.Color(0x331100);
  return mat;
}

// ---------- launcher loading ----------
function prepGeom(g) {
  let geo = g.index ? g : g;
  if (!geo.attributes.normal) geo.computeVertexNormals();
  geo.computeBoundingBox();
  return geo;
}

function loadLauncher(def) {
  clearLauncher();
  const parts = def.parts.map((p, i) => {
    const geom = prepGeom(p.geom);
    return { id: i, name: p.name, geom, material: p.material || 'plywood', infill: p.infill ?? 20, role: p.role || 'base', moments: geomMoments([geom]), mesh: null };
  });
  const r = def.rig || {};
  S.L = {
    name: def.name, parts,
    pivot: r.pivot || null, axis: r.axis || 'z', holder: r.holder || 'cup', cup: r.cup || null,
    sling: r.sling || { attach: null, lengthIn: 6 }, bands: r.bands || [],
    cockDeg: r.cockDeg ?? 45, stopDeg: r.stopDeg ?? 0, releaseDeg: r.releaseDeg ?? 40, friction: r.friction || 'low',
    floorY: r.floorY ?? 0,
  };
  S.axisManual = !!r.pivot;
  for (const p of parts) {
    p.mesh = new THREE.Mesh(p.geom, partMaterial(p));
    p.mesh.castShadow = true; p.mesh.receiveShadow = true; p.mesh.userData.partId = p.id;
  }
  S.sel = -1; S.previewDeg = S.L.cockDeg;
  placeParts(); computeFloor(); refreshAll();
  S.round.used = 0; resetRound();
  if (S.view === 'field') { placement(true); setArm(S.rig && !S.rig.errors.length ? S.rig.cock : 0); syncIdleMarble(); buildArena(); frameField(); }
  else frameRig();
}

function clearLauncher() {
  for (const g of [baseGroup, armGroup, ghostGroup]) for (const c of [...g.children]) if (c !== armMarkers) g.remove(c);
  armMarkers.clear();
  S.L = null; S.sim = null; S.simKey = '';
}

function placeParts() {
  const L = S.L;
  for (const c of [...baseGroup.children]) baseGroup.remove(c);
  for (const c of [...armGroup.children]) if (c !== armMarkers) armGroup.remove(c);
  ghostGroup.clear();
  for (const p of L.parts) {
    p.mesh.material.dispose(); p.mesh.material = partMaterial(p);
    if (p.id === S.sel) p.mesh.material.emissive = new THREE.Color(0x1d6fa8);
    (p.role === 'arm' ? armGroup : baseGroup).add(p.mesh);
    if (p.role === 'arm') {
      const g = new THREE.Mesh(p.geom, new THREE.MeshBasicMaterial({ color: 0x56c2ff, transparent: true, opacity: 0.16, depthWrite: false }));
      ghostGroup.add(g);
    }
  }
}

// lowest support surface under the marble for slings (top of the base board)
function computeFloor() {
  const L = S.L; if (!L || L.floorYManual) return;
  let top = 0;
  const ray = new THREE.Raycaster(new THREE.Vector3(0, 1, 0), new THREE.Vector3(0, -1, 0));
  const bases = L.parts.filter((p) => p.role === 'base').map((p) => p.mesh);
  const xs = [-0.05, 0, 0.05];
  const probes = bases.map((m) => new THREE.Mesh(m.geometry, m.material));
  for (const x of xs) {
    ray.set(new THREE.Vector3(x, 1, 0.05), new THREE.Vector3(0, -1, 0));
    const h = ray.intersectObjects(probes, false)[0];
    if (h) top = Math.max(top, Math.min(h.point.y, 0.06));
  }
  // in rig view, launcherRoot is identity, so world = model
  L.floorY = top;
}

// ---------- arm transforms ----------
function axisVec(L) { return L.axis === 'x' ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 0, 1); }
function armMatrix(thRad) {
  const L = S.L; if (!L || !L.pivot) return new THREE.Matrix4();
  const p = L.pivot;
  return new THREE.Matrix4().makeTranslation(p.x, p.y, p.z)
    .multiply(new THREE.Matrix4().makeRotationAxis(axisVec(L), thRad))
    .multiply(new THREE.Matrix4().makeTranslation(-p.x, -p.y, -p.z));
}
function setArm(thRad) {
  armGroup.matrix.copy(armMatrix(thRad)); armGroup.matrixWorldNeedsUpdate = true;
}

// model-space point on arm (at angle) or frame → world
function modelToWorld(pt, onArm, thRad) {
  const v = pt.clone();
  if (onArm) v.applyMatrix4(armMatrix(thRad));
  return v.applyMatrix4(launcherRoot.matrix);
}

// ---------- placement ----------
function placement(field) {
  const m = new THREE.Matrix4();
  if (!field || !S.rig || S.rig.errors?.length) { launcherRoot.matrix.copy(m); return; }
  const f = S.rig.e1.clone().multiplyScalar(S.rig.fwd);
  const yaw = Math.atan2(f.z, f.x);
  const R = new THREE.Matrix4().makeRotationY(yaw);
  const box = new THREE.Box3();
  for (const p of S.L.parts) if (p.role !== 'ignore') box.union(p.geom.boundingBox.clone().applyMatrix4(R));
  const T = new THREE.Matrix4().makeTranslation(-box.max.x, 0, -(box.min.z + box.max.z) / 2);
  launcherRoot.matrix.copy(T.multiply(R));
}

// ---------- UI: tabs ----------
$$('.tabs button').forEach((b) => b.addEventListener('click', () => setTab(b.dataset.tab)));
function setTab(t) {
  if (S.phase !== 'idle' && t !== 'launch' && t !== 'log') skipShot();
  if (t !== 'launch') $('#results').classList.remove('show');
  S.tab = t;
  $$('.tabs button').forEach((b) => b.classList.toggle('on', b.dataset.tab === t));
  $$('section').forEach((s) => s.classList.toggle('on', s.id === 'tab-' + t));
  const field = t === 'launch' || (t === 'log' && S.view === 'field');
  setView(field ? 'field' : 'rig');
  if (t === 'rig') { $('#stParts').open = true; }
  cancelPick();
}

function setView(v) {
  const was = S.view; S.view = v;
  updateRig();
  placement(v === 'field');
  helperGroup.visible = v === 'rig'; ghostGroup.visible = v === 'rig' && !!S.L?.pivot;
  armMarkers.visible = v === 'rig';
  if (v === 'field') { setArm(S.rig && !S.rig.errors.length ? S.rig.cock : 0); syncIdleMarble(); buildArena(); if (was !== 'field') frameField(); }
  else { setArm((S.previewDeg * Math.PI) / 180); syncIdleMarble(); if (was !== 'rig') frameRig(); }
  updateBands(S.view === 'field' && S.rig && !S.rig.errors.length ? S.rig.cock : (S.previewDeg * Math.PI) / 180);
}

function frameRig() {
  const box = new THREE.Box3();
  if (S.L) for (const p of S.L.parts) box.union(p.geom.boundingBox);
  const c = box.isEmpty() ? new THREE.Vector3(0, 0.1, 0) : box.getCenter(new THREE.Vector3());
  tweenCam(c.clone().add(new THREE.Vector3(0.42, 0.26, 0.5)), c);
  aimSun(c, 0.6);
}
function frameField() {
  const D = S.tgtFt * FT;
  const tgt = new THREE.Vector3(Math.min(D, 6) * 0.45, 0.05, 0);
  tweenCam(new THREE.Vector3(-0.9, 0.75, 1.7), tgt);
  aimSun(new THREE.Vector3(0.2, 0, 0), 1.0);
}
let camTween = null;
function tweenCam(pos, target, dur = 0.8) {
  camTween = { p0: camera.position.clone(), t0: controls.target.clone(), p1: pos, t1: target, k: 0, dur };
}

// ---------- BUILD tab ----------
$('#sampleCat').onclick = () => { S.importState = null; $('#importOpts').style.display = 'none'; loadLauncher(sampleCatapult()); markSample('#sampleCat'); };
$('#sampleTreb').onclick = () => { S.importState = null; $('#importOpts').style.display = 'none'; loadLauncher(sampleTrebuchet()); markSample('#sampleTreb'); };
function markSample(id) { $$('#tab-build .card').forEach((c) => c.classList.toggle('on', '#' + c.id === id)); }
$('#toRig').onclick = () => setTab('rig');

const drop = $('#drop');
drop.addEventListener('dragover', (e) => { e.preventDefault(); drop.classList.add('over'); });
drop.addEventListener('dragleave', () => drop.classList.remove('over'));
drop.addEventListener('drop', (e) => { e.preventDefault(); drop.classList.remove('over'); handleFiles([...e.dataTransfer.files]); });
$('#file').addEventListener('change', (e) => { handleFiles([...e.target.files]); e.target.value = ''; });
window.addEventListener('dragover', (e) => e.preventDefault());
window.addEventListener('drop', (e) => { e.preventDefault(); if (e.dataTransfer?.files?.length) handleFiles([...e.dataTransfer.files]); });

async function handleFiles(files) {
  if (!files.length) return;
  try {
    const raw = [];
    let name = files[0].name.replace(/\.[^.]+$/, '');
    const glb = files.find((f) => /\.(glb|gltf)$/i.test(f.name));
    if (glb) {
      const buf = await glb.arrayBuffer();
      const gltf = await new GLTFLoader().parseAsync(/\.gltf$/i.test(glb.name) ? new TextDecoder().decode(buf) : buf, '');
      gltf.scene.updateMatrixWorld(true);
      const groups = new Map();
      const assoc = gltf.parser.associations;
      gltf.scene.traverse((o) => {
        if (!o.isMesh) return;
        const a = assoc.get(o), pa = o.parent && assoc.get(o.parent);
        const multi = a && a.primitives !== undefined && pa && pa.meshes === a.meshes && pa.primitives === undefined;
        const key = multi ? o.parent : o;
        if (!groups.has(key)) groups.set(key, []);
        groups.get(key).push(o);
      });
      let i = 1;
      for (const [key, meshes] of groups) {
        const geoms = meshes.map((m) => {
          const g = new THREE.BufferGeometry();
          g.setAttribute('position', m.geometry.attributes.position.clone());
          if (m.geometry.index) g.setIndex(m.geometry.index.clone());
          g.applyMatrix4(m.matrixWorld);
          if (m.matrixWorld.determinant() < 0) flipWinding(g);
          return g;
        });
        const geom = geoms.length > 1 ? mergeGeoms(geoms) : geoms[0];
        const nm = [key.name, key.parent && key.parent !== gltf.scene ? key.parent.name : '', meshes[0].name].find((n) => n && !/^(mesh|node|object)_?\d*$/i.test(n));
        raw.push({ name: cleanName(nm || `Part ${i}`), geom });
        i++;
      }
    } else {
      for (const f of files.filter((f) => /\.stl$/i.test(f.name))) {
        const g = new STLLoader().parse(await f.arrayBuffer());
        raw.push({ name: cleanName(f.name.replace(/\.stl$/i, '')), geom: g });
      }
      if (files.length > 1) name = 'Imported launcher';
    }
    if (!raw.length) throw new Error('No parts found in that file.');
    S.importState = { raw, name, units: 'auto', up: 'y' };
    $('#importOpts').style.display = '';
    segSet('#segUnits', 'auto'); segSet('#segUp', 'y');
    markSample(null);
    buildImported();
    toast('Imported!', `${raw.length} part${raw.length > 1 ? 's' : ''} found. Check units and up direction, then rig it.`);
  } catch (err) {
    console.error(err);
    toast('Import failed', String(err.message || err), true);
  }
}
function cleanName(n) { return String(n).replace(/_/g, ' ').replace(/\s*<\d+>\s*$/, '').replace(/\s+\d+$/, (m) => m).trim() || 'Part'; }
function flipWinding(g) {
  if (g.index) { const a = g.index.array; for (let i = 0; i < a.length; i += 3) { const t = a[i + 1]; a[i + 1] = a[i + 2]; a[i + 2] = t; } }
  else { const p = g.attributes.position.array; for (let i = 0; i < p.length; i += 9) for (let k = 0; k < 3; k++) { const t = p[i + 3 + k]; p[i + 3 + k] = p[i + 6 + k]; p[i + 6 + k] = t; } }
}
function mergeGeoms(gs) {
  const arrs = gs.map((g) => (g.index ? g.toNonIndexed() : g).attributes.position.array);
  const out = new Float32Array(arrs.reduce((s, a) => s + a.length, 0));
  let o = 0; for (const a of arrs) { out.set(a, o); o += a.length; }
  const g = new THREE.BufferGeometry(); g.setAttribute('position', new THREE.BufferAttribute(out, 3));
  return g;
}

function buildImported() {
  const st = S.importState; if (!st) return;
  const box = new THREE.Box3();
  for (const r of st.raw) { r.geom.computeBoundingBox(); box.union(r.geom.boundingBox); }
  const size = box.getSize(new THREE.Vector3());
  const maxDim = Math.max(size.x, size.y, size.z);
  let scale = 1;
  if (st.units === 'mm') scale = 0.001;
  else if (st.units === 'in') scale = IN;
  else if (st.units === 'auto') scale = maxDim > 30 ? 0.001 : maxDim > 1.2 ? IN : 1;
  const R = new THREE.Matrix4();
  if (st.up === 'z') R.makeRotationX(-Math.PI / 2);
  else if (st.up === '-z') R.makeRotationX(Math.PI / 2);
  else if (st.up === 'x') R.makeRotationZ(Math.PI / 2);
  else if (st.up === '-y') R.makeRotationX(Math.PI);
  const M = R.multiply(new THREE.Matrix4().makeScale(scale, scale, scale));
  const geoms = st.raw.map((r) => { const g = r.geom.clone(); g.applyMatrix4(M); g.deleteAttribute('normal'); g.computeBoundingBox(); return g; });
  const all = new THREE.Box3(); geoms.forEach((g) => all.union(g.boundingBox));
  const c = all.getCenter(new THREE.Vector3());
  geoms.forEach((g) => { g.translate(-c.x, -all.min.y, -c.z); g.computeVertexNormals(); g.computeBoundingBox(); });
  let cup = null;
  const parts = st.raw.map((r, i) => {
    const n = r.name.toLowerCase();
    const bb = geoms[i].boundingBox, sz = bb.getSize(new THREE.Vector3());
    let role = 'base', material = 'plywood', infill = 20;
    if (/\bpla\b|print|\b3d\b|petg|cup|spoon|bucket|pouch/.test(n)) material = 'pla';
    if (/bolt|screw|washer|nut|rod|axle|pin|steel/.test(n)) material = 'steel';
    if (/weight|counter|cw\b/.test(n)) { material = 'steel'; role = 'arm'; }
    if (/lead|sinker/.test(n)) material = 'lead';
    if (/dowel|pine/.test(n)) material = 'pine';
    if (/arm|lever|beam|throw|spoon|cup|bucket/.test(n)) role = 'arm';
    const isMarble = (/marble|\bball\b/.test(n) && !/cup|holder|spoon|arm|launch|track|ramp/.test(n) && Math.max(sz.x, sz.y, sz.z) < 0.03) || (Math.max(sz.x, sz.y, sz.z) < 0.022 && Math.min(sz.x, sz.y, sz.z) > 0.012 && Math.max(sz.x, sz.y, sz.z) / Math.min(sz.x, sz.y, sz.z) < 1.15);
    if (isMarble) { role = 'ignore'; material = 'massless'; cup = bb.getCenter(new THREE.Vector3()); }
    return { name: r.name, geom: geoms[i], material, role, infill };
  });
  loadLauncher({ name: st.name, parts, rig: { cup, holder: 'cup', cockDeg: 45, stopDeg: 0 } });
  if (cup) toast('Marble found in your CAD', 'Marble spot set automatically. Its part is ignored for weight.');
  autoAxis();
}

function segSet(sel, v) { $$(sel + ' button').forEach((b) => b.classList.toggle('on', b.dataset.v === v)); }
function segBind(sel, fn) { $$(sel + ' button').forEach((b) => b.addEventListener('click', () => { segSet(sel, b.dataset.v); fn(b.dataset.v); })); }
segBind('#segUnits', (v) => { S.importState.units = v; buildImported(); });
segBind('#segUp', (v) => { S.importState.up = v; buildImported(); });

$('#exportGlb').onclick = () => {
  if (!S.L) return toast('Nothing to save', 'Load a launcher first.', true);
  const root = new THREE.Scene();
  for (const p of S.L.parts) { const m = new THREE.Mesh(p.geom, new THREE.MeshStandardMaterial({ color: MATERIALS[p.material].color })); m.name = p.name; root.add(m); }
  new GLTFExporter().parse(root, (buf) => {
    try {
      const url = URL.createObjectURL(new Blob([buf], { type: 'model/gltf-binary' }));
      const a = document.createElement('a'); a.href = url; a.download = (S.L.name || 'launcher').replace(/[^\w-]+/g, '_') + '.glb'; a.click();
      setTimeout(() => URL.revokeObjectURL(url), 3000);
    } catch { toast('Download blocked', 'Your browser blocked the download here.', true); }
  }, (e) => toast('Export failed', String(e), true), { binary: true });
};

function rulesCheck() {
  const el = $('#rules'); const L = S.L;
  if (!L) { el.innerHTML = '<p class="help">Load a launcher to check it.</p>'; return; }
  const box = new THREE.Box3();
  for (const p of L.parts) if (p.role !== 'ignore') box.union(p.geom.boundingBox);
  const sz = box.getSize(new THREE.Vector3());
  const dims = [sz.x, sz.z, sz.y].map((v) => v / IN);
  const fits = dims.every((d) => d <= 12.05);
  const wood = L.parts.filter((p) => p.role !== 'ignore' && MATERIALS[p.material]?.wood).length;
  const printed = L.parts.filter((p) => p.role !== 'ignore' && MATERIALS[p.material]?.printed).length;
  const bands = L.bands.filter((b) => b.p1 && b.p2).length;
  const armMass = L.parts.filter((p) => p.role === 'arm').reduce((s, p) => s + effectiveDensity(p.material, p.infill) * p.moments.vol, 0);
  const items = [
    [fits, `Fits in 12″ cube at rest: ${dims.map((d) => d.toFixed(1)).join(' × ')} in`],
    [wood >= 2, `At least two cut wood parts (${wood})`],
    [printed <= 2, `Up to two 3D-printed parts (${printed})`],
    [true, 'Standard 16 mm glass marble (5.4 g)'],
    [bands > 0 || armMass > 0.1, `Energy: ${bands ? bands + ' band/spring' + (bands > 1 ? 's' : '') : ''}${bands && armMass > 0.1 ? ' + ' : ''}${armMass > 0.1 ? 'gravity / counterweight' : ''}${!bands && armMass <= 0.1 ? 'none set up yet' : ''}`],
  ];
  el.innerHTML = items.map(([ok, t]) => `<div class="check"><i class="${ok ? 'ok' : 'bad'}">${ok ? '✔' : '✖'}</i><span>${t}</span></div>`).join('');
  cubeHelper.position.set((box.min.x + box.max.x) / 2, 6 * IN, (box.min.z + box.max.z) / 2);
  cubeHelper.material.color.set(fits ? 0x6fd38a : 0xff5b4a);
}

// ---------- RIG tab ----------
const ROLE_LABEL = { base: 'Frame (fixed)', arm: 'Arm (swings)', ignore: 'Ignore' };
function renderParts() {
  const L = S.L; const el = $('#partsList');
  if (!L) { el.innerHTML = '<p class="help">Load a launcher on the Build tab first.</p>'; return; }
  const matOpts = Object.entries(MATERIALS).map(([k, m]) => `<option value="${k}">${m.label}</option>`).join('');
  el.innerHTML = L.parts.map((p) => {
    const mass = effectiveDensity(p.material, p.infill) * p.moments.vol * 1000;
    return `<div class="part ${p.id === S.sel ? 'sel' : ''}" data-id="${p.id}">
      <div class="top"><span class="role-${p.role}">${esc(p.name)}</span><span>${mass < 1000 ? mass.toFixed(1) + ' g' : (mass / 1000).toFixed(2) + ' kg'}${p.moments.ok ? '' : ' ⚠'}</span></div>
      <div class="ctl"><select data-k="role">${Object.entries(ROLE_LABEL).map(([k, v]) => `<option value="${k}" ${k === p.role ? 'selected' : ''}>${v}</option>`).join('')}</select>
      <select data-k="material">${matOpts.replace(`value="${p.material}"`, `value="${p.material}" selected`)}</select>
      ${MATERIALS[p.material]?.printed ? `<select data-k="infill" title="Infill">${[10, 15, 20, 25, 40, 60, 100].map((v) => `<option value="${v}" ${+p.infill === v ? 'selected' : ''}>${v}%</option>`).join('')}</select>` : ''}</div></div>`;
  }).join('');
  el.querySelectorAll('.part').forEach((row) => {
    const p = L.parts[+row.dataset.id];
    row.addEventListener('click', (e) => { if (e.target.tagName !== 'SELECT' && e.target.tagName !== 'OPTION') selectPart(p.id); });
    row.querySelectorAll('select').forEach((s) => s.addEventListener('change', () => {
      p[s.dataset.k] = s.dataset.k === 'infill' ? +s.value : s.value;
      if (s.dataset.k === 'role') { placeParts(); computeFloor(); if (p.role === 'arm') autoAxis(); }
      else placeParts();
      refreshAll();
    }));
  });
  const am = L.parts.filter((p) => p.role === 'arm').reduce((s, p) => s + effectiveDensity(p.material, p.infill) * p.moments.vol, 0);
  const bm = L.parts.filter((p) => p.role === 'base').reduce((s, p) => s + effectiveDensity(p.material, p.infill) * p.moments.vol, 0);
  $('#armMass').textContent = (am * 1000).toFixed(0) + ' g';
  $('#baseMass').textContent = (bm * 1000).toFixed(0) + ' g';
}
const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));

function selectPart(id) {
  S.sel = S.sel === id ? -1 : id;
  placeParts(); renderParts();
  const row = $(`.part[data-id="${id}"]`); if (row) row.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}

function autoAxis() {
  const L = S.L; if (!L || S.axisManual) return;
  const box = new THREE.Box3();
  for (const p of L.parts) if (p.role === 'arm') box.union(p.geom.boundingBox);
  if (box.isEmpty()) return;
  const sz = box.getSize(new THREE.Vector3());
  L.axis = sz.x >= sz.z ? 'z' : 'x';
  segSet('#segAxis', L.axis);
}
segBind('#segAxis', (v) => { S.L && (S.L.axis = v); S.axisManual = true; refreshAll(); });
segBind('#segHolder', (v) => { if (!S.L) return; S.L.holder = v; refreshAll(); });
$('#friction').onchange = (e) => { if (S.L) { S.L.friction = e.target.value; refreshAll(); } };
$('#slingLen').oninput = (e) => { if (S.L) { S.L.sling.lengthIn = Math.max(1, +e.target.value || 6); refreshAll(); } };
$('#releaseDeg').oninput = (e) => { if (S.L) { S.L.releaseDeg = +e.target.value; $('#releaseDegV').textContent = e.target.value + '°'; refreshAll(); } };
$('#cockDeg').oninput = (e) => { if (S.L) { S.L.cockDeg = +e.target.value; S.previewDeg = S.L.cockDeg; refreshAll(); } };
$('#stopDeg').oninput = (e) => { if (S.L) { S.L.stopDeg = +e.target.value; refreshAll(); } };
$('#viewCock').onclick = () => { if (S.L) { S.previewDeg = S.L.cockDeg; refreshAll(); } };
$('#viewCad').onclick = () => { S.previewDeg = 0; refreshAll(); };

$('#addBand').onclick = () => {
  if (!S.L) return;
  S.L.bands.push({ p1: null, p1Arm: false, p2: null, p2Arm: false, count: 1, restIn: 3.5, kNpm: 80 });
  refreshAll();
  $('#stPower').open = true;
};

function renderBands() {
  const L = S.L; const el = $('#bands');
  if (!L) { el.innerHTML = ''; return; }
  const lens = S.rig && !S.rig.errors.length ? bandLengths(S.rig, (S.previewDeg * Math.PI) / 180) : [];
  let vi = 0;
  el.innerHTML = L.bands.map((b, i) => {
    const valid = b.p1 && b.p2; const len = valid ? lens[vi++] : null;
    return `<div class="band" data-i="${i}">
    <div class="row"><b style="flex:1">Band / spring ${i + 1}</b><button class="btn" data-a="del" title="Remove">🗑</button></div>
    <div class="row"><button class="btn pick" data-pick="band${i}a">${b.p1 ? '✔' : '🎯'} End 1 ${b.p1 ? (b.p1Arm ? '(arm)' : '(frame)') : ''}</button>
      <button class="btn pick" data-pick="band${i}b">${b.p2 ? '✔' : '🎯'} End 2 ${b.p2 ? (b.p2Arm ? '(arm)' : '(frame)') : ''}</button></div>
    <div class="row"><label>How many bands (side by side)</label><input type="number" min="1" max="12" step="1" value="${b.count}" data-k="count"></div>
    <div class="row"><label>Unstretched length (in)</label><input type="number" min="0.25" max="24" step="0.25" value="${b.restIn}" data-k="restIn"></div>
    <div class="row"><label>Strength per band k (N/m)</label><input type="number" min="1" max="5000" step="1" value="${b.kNpm}" data-k="kNpm"></div>
    <details><summary class="kbd" style="cursor:pointer">🧪 Calibrate from a hanging-weight test</summary>
      <div class="row"><label>Weight hung (g)</label><input type="number" value="500" data-c="g"></div>
      <div class="row"><label>Stretched length (in)</label><input type="number" value="6" step="0.125" data-c="len"></div>
      <button class="btn full" data-a="cal">Calculate k</button></details>
    ${len != null ? `<p class="help" style="margin:6px 0 0">Shown stretched: ${(len / IN).toFixed(2)} in ${len / IN < b.restIn ? '<span class="warn">(slack — no pull)</span>' : ''}</p>` : '<p class="help warn" style="margin:6px 0 0">Pick both ends: one on the frame, one on the arm.</p>'}
    </div>`;
  }).join('') || '<p class="help">No bands yet.</p>';
  el.querySelectorAll('.band').forEach((row) => {
    const b = L.bands[+row.dataset.i];
    row.querySelectorAll('input[data-k]').forEach((inp) => inp.addEventListener('change', () => { b[inp.dataset.k] = Math.max(+inp.min || 0, +inp.value || 0); refreshAll(); }));
    row.querySelector('[data-a="del"]').onclick = () => { L.bands.splice(+row.dataset.i, 1); refreshAll(); };
    row.querySelector('[data-a="cal"]').onclick = () => {
      const g = +row.querySelector('[data-c="g"]').value, len = +row.querySelector('[data-c="len"]').value;
      const stretch = (len - b.restIn) * IN;
      if (stretch <= 0) return toast('Check your numbers', 'Stretched length must be longer than unstretched length.', true);
      b.kNpm = Math.round((g / 1000) * G / stretch);
      toast('Band calibrated', `k = ${b.kNpm} N/m per band`); refreshAll();
    };
  });
  bindPickButtons(el);
}

function bindPickButtons(root = document) {
  root.querySelectorAll('[data-pick]').forEach((b) => { b.onclick = () => startPick(b.dataset.pick); b.classList.toggle('picking', S.pick === b.dataset.pick); });
}
const PICK_TEXT = {
  pivot: 'Click the end of your axle (pivot) on the model',
  cup: 'Click the inside bottom of the cup where the marble sits',
  sling: 'Click the sling hook / release pin at the end of the arm',
};
function startPick(kind) {
  if (!S.L) return;
  if (S.view !== 'rig') setTab('rig');
  S.pick = kind;
  $('#hintText').textContent = PICK_TEXT[kind] || `Click where band end ${kind.endsWith('a') ? 1 : 2} hooks on (frame or arm)`;
  $('#hint').style.display = 'block';
  bindPickButtons();
}
function cancelPick() { S.pick = null; $('#hint').style.display = 'none'; bindPickButtons(); }
$('#hintCancel').onclick = cancelPick;
addEventListener('keydown', (e) => { if (e.key === 'Escape') cancelPick(); });

// pointer picking
const ray = new THREE.Raycaster();
let downXY = null;
canvas.addEventListener('pointerdown', (e) => { downXY = [e.clientX, e.clientY]; });
canvas.addEventListener('pointerup', (e) => {
  if (!downXY || Math.hypot(e.clientX - downXY[0], e.clientY - downXY[1]) > 5) return;
  if (S.view !== 'rig' || !S.L) return;
  const r = canvas.getBoundingClientRect();
  ray.setFromCamera(new THREE.Vector2(((e.clientX - r.left) / r.width) * 2 - 1, -((e.clientY - r.top) / r.height) * 2 + 1), camera);
  const meshes = S.L.parts.map((p) => p.mesh);
  launcherRoot.updateMatrixWorld(true);
  const hit = ray.intersectObjects(meshes, false)[0];
  if (!hit) return;
  const part = S.L.parts[hit.object.userData.partId];
  if (!S.pick) { selectPart(part.id); if (S.tab !== 'rig') setTab('rig'); $('#stParts').open = true; return; }
  const local = hit.object.worldToLocal(hit.point.clone()); // model space (arm at CAD pose)
  const onArm = part.role === 'arm';
  const L = S.L; const k = S.pick;
  if (k === 'pivot') { L.pivot = local; autoAxis(); $('#stHolder').open = true; }
  else if (k === 'cup') {
    if (!onArm) toast('Heads up', 'That spot is on the frame, not the arm. Pick the cup on the moving arm.', true);
    const n = hit.face.normal.clone();
    const dirLocal = ray.ray.direction.clone().transformDirection(new THREE.Matrix4().copy(hit.object.matrixWorld).invert());
    if (n.dot(dirLocal) > 0) n.negate();
    L.cup = local.addScaledVector(n, MARBLE_R + 0.0005);
  } else if (k === 'sling') {
    if (!onArm) toast('Heads up', 'The sling hook should be on the arm.', true);
    L.sling.attach = local;
  } else if (k.startsWith('band')) {
    const i = parseInt(k.slice(4)); const b = L.bands[i]; if (!b) return;
    if (k.endsWith('a')) { b.p1 = local; b.p1Arm = onArm; } else { b.p2 = local; b.p2Arm = onArm; }
    if (k.endsWith('a') && !b.p2) { refreshAll(); return startPick(`band${i}b`); }
  }
  cancelPick(); refreshAll();
});

function stepStatus(id, ok, text) { const el = $(id); el.innerHTML = ok ? `<span class="ok">✔ ${text || ''}</span>` : `<span class="warn">● ${text || 'to do'}</span>`; }

function updateRig() {
  if (!S.L) { S.rig = null; return; }
  S.rig = buildRig({ ...S.L, parts: S.L.parts });
}

function refreshAll() {
  updateRig();
  const L = S.L;
  renderParts(); renderBands(); rulesCheck(); bindPickButtons();
  if (L) {
    segSet('#segAxis', L.axis); segSet('#segHolder', L.holder);
    $('#friction').value = L.friction;
    $('#holderCup').style.display = L.holder === 'cup' ? '' : 'none';
    $('#holderSling').style.display = L.holder === 'sling' ? '' : 'none';
    $('#slingLen').value = L.sling.lengthIn; $('#releaseDeg').value = L.releaseDeg; $('#releaseDegV').textContent = L.releaseDeg + '°';
    $('#cockDeg').value = L.cockDeg; $('#cockDegV').textContent = L.cockDeg + '°';
    $('#stopDeg').value = L.stopDeg; $('#stopDegV').textContent = L.stopDeg + '°';
    const arms = L.parts.filter((p) => p.role === 'arm').length;
    stepStatus('#stPartsS', arms > 0 && L.parts.some((p) => p.role === 'base'), arms ? `${arms} arm part${arms > 1 ? 's' : ''}` : 'mark the arm');
    stepStatus('#stPivotS', !!L.pivot, L.pivot ? 'set' : 'pick it');
    stepStatus('#stHolderS', L.holder === 'cup' ? !!L.cup : !!L.sling.attach, L.holder === 'cup' ? (L.cup ? 'cup' : 'pick spot') : (L.sling.attach ? 'sling' : 'pick hook'));
    const nb = L.bands.filter((b) => b.p1 && b.p2).length;
    stepStatus('#stPowerS', true, nb ? `${nb} band${nb > 1 ? 's' : ''}` : 'gravity only');
    stepStatus('#stMotionS', L.cockDeg !== L.stopDeg, `${L.cockDeg}° → ${L.stopDeg}°`);
  }
  const msgs = S.rig ? S.rig.errors : ['Load a launcher on the Build tab.'];
  $('#rigMsgs').innerHTML = msgs.map((m) => `<div class="check"><i class="bad">✖</i><span>${m}</span></div>`).join('');
  $('#btnLaunch').disabled = !!msgs.length;
  if (S.view === 'rig') {
    setArm((S.previewDeg * Math.PI) / 180);
    ghostGroup.matrix.copy(armMatrix(((L?.stopDeg ?? 0) * Math.PI) / 180)); ghostGroup.matrixWorldNeedsUpdate = true;
    ghostGroup.visible = !!L?.pivot;
  } else placement(true);
  drawMarkers();
  syncIdleMarble();
  updateBands(S.view === 'field' && S.rig && !S.rig.errors.length ? S.rig.cock : (S.previewDeg * Math.PI) / 180);
  clearTimeout(preT); preT = setTimeout(preStats, 120);
}
let preT = 0;

function drawMarkers() {
  armMarkers.clear();
  const L = S.L; if (!L) { pivotLine.visible = pivotDot.visible = false; return; }
  pivotLine.visible = pivotDot.visible = !!L.pivot;
  if (L.pivot) {
    pivotDot.position.copy(L.pivot); pivotLine.position.copy(L.pivot);
    pivotLine.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), axisVec(L));
  }
  const dot = (p, color, arm) => {
    const m = new THREE.Mesh(new THREE.SphereGeometry(0.0045, 10, 8), new THREE.MeshBasicMaterial({ color, depthTest: false, transparent: true }));
    m.renderOrder = 6; m.position.copy(p); (arm ? armMarkers : helperGroup).add(m); if (!arm) m.userData.tmp = true;
  };
  helperGroup.children.filter((c) => c.userData.tmp).forEach((c) => helperGroup.remove(c));
  for (const b of L.bands) { if (b.p1) dot(b.p1, 0xffd36b, b.p1Arm); if (b.p2) dot(b.p2, 0xffd36b, b.p2Arm); }
  if (L.holder === 'sling' && L.sling.attach) dot(L.sling.attach, 0xff7a1a, true);
}

// marble resting position (rig view or field idle)
function syncIdleMarble() {
  const L = S.L;
  if (S.phase !== 'idle') return;
  marble.visible = !!L; slingMesh.visible = pouch.visible = false;
  if (!L) return;
  const th = S.view === 'field' && S.rig && !S.rig.errors.length ? S.rig.cock : (S.previewDeg * Math.PI) / 180;
  if (L.holder === 'cup' && L.cup) { marble.position.copy(modelToWorld(L.cup, true, th)); }
  else if (L.holder === 'sling' && L.sling.attach) {
    const tip = modelToWorld(L.sling.attach, true, th);
    const r = S.rig;
    let mp;
    if (r && !r.errors.length) {
      // same initial sling pose as the simulator
      const sl = r.sl, b = sl.alpha + th, Ls = r.slL;
      const tx = sl.rho * Math.cos(b), ty = sl.rho * Math.sin(b);
      let ph = -Math.PI / 2;
      if (ty - Ls < r.groundY) { const sn = Math.max(-1, Math.min(1, (r.groundY - ty) / Ls)); ph = Math.atan2(sn, Math.sqrt(1 - sn * sn) * r.fwd); }
      mp = r.fromPlane(tx + Ls * Math.cos(ph), ty + Ls * Math.sin(ph), sl.z).applyMatrix4(launcherRoot.matrix);
    } else mp = tip.clone().add(new THREE.Vector3(0, -L.sling.lengthIn * IN, 0));
    marble.position.copy(mp);
    drawSling(tip, mp);
  } else marble.visible = false;
}
function drawSling(tip, m) {
  slingMesh.visible = pouch.visible = true;
  const d = m.clone().sub(tip); const len = d.length();
  slingMesh.position.copy(tip).addScaledVector(d, 0.5);
  slingMesh.scale.set(1, Math.max(len, 1e-4), 1);
  slingMesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize());
  pouch.position.copy(m);
}

function updateBands(th) {
  const L = S.L; const list = L ? L.bands.filter((b) => b.p1 && b.p2) : [];
  while (bandMeshes.length < list.length) { const m = new THREE.Mesh(new THREE.CylinderGeometry(1, 1, 1, 8), bandMat.clone()); m.castShadow = true; scene.add(m); bandMeshes.push(m); }
  bandMeshes.forEach((m, i) => {
    const b = list[i]; m.visible = !!b; if (!b) return;
    const a = modelToWorld(b.p1, b.p1Arm, th), c = modelToWorld(b.p2, b.p2Arm, th);
    const d = c.clone().sub(a); const len = d.length();
    const stretch = Math.max(0, len / (b.restIn * IN) - 1);
    const r = 0.0016 * Math.sqrt(b.count) / Math.sqrt(1 + stretch);
    m.position.copy(a).addScaledVector(d, 0.5); m.scale.set(r, Math.max(len, 1e-4), r);
    m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d.normalize());
    m.material.color.setHSL(0.09 - Math.min(stretch, 2) * 0.045, 0.6, 0.5);
  });
}

function preStats() {
  const el = $('#preStats'); const r = S.rig;
  if (!r || r.errors.length) { el.innerHTML = ''; return; }
  const sim = getSim();
  el.innerHTML = [
    ['Arm mass', (r.M * 1000).toFixed(0) + ' g'],
    ['Stored energy', sim.stats.usedJ.toFixed(2) + ' J'],
    ['Launch speed', sim.speed.toFixed(1) + ' m/s'],
    ['Launch angle', deg(sim.angle).toFixed(0) + '°'],
  ].map(([a, b]) => `<div class="stat"><small>${a}</small><b>${b}</b></div>`).join('');
}

function getSim() {
  const L = S.L;
  const key = JSON.stringify({ p: L.parts.map((p) => [p.role, p.material, p.infill]), pv: L.pivot, a: L.axis, h: L.holder, c: L.cup, s: L.sling, b: L.bands, ck: L.cockDeg, st: L.stopDeg, rl: L.releaseDeg, f: L.friction, fy: L.floorY });
  if (S.sim && S.simKey === key) return S.sim;
  S.sim = simulateLaunch(S.rig); S.simKey = key;
  return S.sim;
}

// ---------- LAUNCH tab ----------
$$('.mode').forEach((c) => c.addEventListener('click', () => {
  if (S.phase !== 'idle') skipShot();
  S.mode = c.dataset.mode; $$('.mode').forEach((x) => x.classList.toggle('on', x === c));
  resetRound(); buildArena(); updateLaunchUI(); frameField();
}));
function updateLaunchUI() {
  $('#optTarget').style.display = S.mode === 'distance' ? 'none' : '';
  $('#optCastle').style.display = S.mode === 'siege' ? '' : 'none';
  $('#tgtLabel').textContent = S.mode === 'siege' ? 'Castle distance' : 'Target distance';
  $('#tgtFtV').textContent = S.tgtFt + ' ft';
  $('#shots').innerHTML = 'Launches this round: ' + [0, 1, 2].map((i) => `<i class="${i < S.round.used ? 'used' : ''}"></i>`).join('') + (S.mode === 'siege' ? ` &nbsp;Score <b style="color:var(--gold)">${S.round.score}</b>` : '');
}
$('#tgtFt').oninput = (e) => { S.tgtFt = +e.target.value; $('#tgtFtV').textContent = S.tgtFt + ' ft'; if (S.phase !== 'idle') skipShot(); resetRound(); buildArena(); updateLaunchUI(); };
$('#tgtAuto').onclick = () => {
  const last = [...S.log].reverse().find((l) => l.distM != null);
  let d = last ? last.distM : null;
  if (d == null && S.rig && !S.rig.errors.length) { placement(true); const sim = getSim(); const p = sim.pos.clone().applyMatrix4(launcherRoot.matrix); const v = sim.vel.clone().transformDirection(launcherRoot.matrix).multiplyScalar(sim.speed); d = estimateRange(p, v); }
  if (d == null) return toast('Launch once first', 'Then the castle can move to where you land.', true);
  S.tgtFt = Math.max(3, Math.min(40, Math.round((d / FT) * 2) / 2)); $('#tgtFt').value = S.tgtFt; $('#tgtFt').oninput({ target: $('#tgtFt') });
};
function estimateRange(p, v) {
  const k = (0.5 * 1.2 * 0.47 * Math.PI * MARBLE_R ** 2) / MARBLE_M; let x = p.x, y = p.y, vx = v.x, vy = v.y, t = 0;
  while (t < 8) { const s = Math.hypot(vx, vy); vx -= k * s * vx / 1000; vy -= (G + k * s * vy) / 1000; x += vx / 1000; y += vy / 1000; t += 0.001; if (y < MARBLE_R && vy < 0) break; }
  return x;
}
segBind('#segCastle', (v) => { S.castle = v; if (S.phase !== 'idle') skipShot(); resetRound(); buildArena(); });
$('#ignite').onchange = (e) => { S.ignite = e.target.checked; };
$('#slowmo').onchange = (e) => { S.slowmo = e.target.checked; };
$('#trail').onchange = (e) => { S.trail = e.target.checked; trails.forEach((t) => (t.visible = S.trail)); };
$('#btnLaunch').onclick = () => launch();
$('#btnReplay').onclick = () => replay();
$('#btnNewRound').onclick = () => { if (S.phase !== 'idle') skipShot(); resetRound(); buildArena(); updateLaunchUI(); toast('New round', 'Fresh castle, 3 launches.'); };
addEventListener('keydown', (e) => {
  if (e.target.tagName === 'INPUT' || e.target.tagName === 'SELECT') return;
  if (e.code === 'Space' && S.tab === 'launch') { e.preventDefault(); if (S.phase === 'idle' || S.phase === 'results') launch(); }
  if (e.key === 'r' && S.tab === 'launch') replay();
});

// ---------- physics world (castle + flight) ----------
let world = null, groundCol = null;
const objs = []; // castle objects
const colToObj = new Map();
const stoneTex = stoneTexture();
const looks = {
  stone: new THREE.MeshStandardMaterial({ map: stoneTex, color: 0xd8d2c8, roughness: 0.9 }),
  roof: new THREE.MeshStandardMaterial({ color: 0x8e2b22, roughness: 0.7 }),
  wood: new THREE.MeshStandardMaterial({ map: woodTex, color: 0xa0743f, roughness: 0.85 }),
};
const castleGroup = new THREE.Group(); scene.add(castleGroup);
const pinsGroup = new THREE.Group(); scene.add(pinsGroup);
const trails = [];

function mulberry(a) { return () => { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

function newWorld() {
  if (world) world.free();
  world = new RAPIER.World({ x: 0, y: -G, z: 0 });
  world.timestep = DT; world.lengthUnit = 0.05; world.numSolverIterations = 8;
  const gb = world.createRigidBody(RAPIER.RigidBodyDesc.fixed());
  groundCol = world.createCollider(RAPIER.ColliderDesc.cuboid(80, 0.5, 80).setTranslation(0, -0.5, 0).setFriction(0.8).setRestitution(0.3), gb);
  colToObj.clear();
}

function resetRound() {
  S.round = { n: S.round.n + 1, used: 0, score: 0, seed: 1234 + S.round.n, best: 0, burned: 0 };
  S.shot = null; S.snap = null; S.phase = 'idle';
  pinsGroup.clear(); trails.forEach((t) => scene.remove(t)); trails.length = 0;
  fire.clear(); smoke.clear();
  updateLaunchUI();
}

function buildArena() {
  newWorld();
  for (const o of objs) castleGroup.remove(o.mesh);
  objs.length = 0;
  const D = S.tgtFt * FT;
  rings.visible = S.mode === 'target'; rings.position.x = D;
  if (S.mode === 'siege') {
    const specs = CASTLES[S.castle].build();
    const rng = mulberry(77);
    for (const sp of specs) {
      const x = D + sp.p[0], y = sp.p[1], z = sp.p[2];
      let body, mesh, col, kind = sp.kind;
      if (kind === 'block') {
        body = world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(x, y, z).setCanSleep(true).setSleeping(true));
        col = world.createCollider(RAPIER.ColliderDesc.cuboid(...sp.he).setDensity(150).setFriction(0.7).setRestitution(0.05), body);
        const mat = looks[sp.look].clone(); const v = 0.85 + rng() * 0.2; mat.color.multiplyScalar(v);
        mesh = new THREE.Mesh(new THREE.BoxGeometry(sp.he[0] * 2, sp.he[1] * 2, sp.he[2] * 2), mat);
      } else if (kind === 'guard') {
        body = world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(x, y, z).setCanSleep(true).setSleeping(true));
        col = world.createCollider(RAPIER.ColliderDesc.cylinder(0.018, 0.012).setTranslation(0, 0.018, 0).setDensity(250).setFriction(0.8), body);
        const c2 = world.createCollider(RAPIER.ColliderDesc.ball(0.011).setTranslation(0, 0.047, 0).setDensity(250), body);
        mesh = makeGuard(rng);
        colToObj.set(c2.handle, objs.length);
      } else {
        body = world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(x, y, z).setCanSleep(true).setSleeping(true));
        col = world.createCollider(RAPIER.ColliderDesc.cuboid(0.016, 0.004, 0.016).setTranslation(0, 0.004, 0).setDensity(300).setFriction(0.8), body);
        world.createCollider(RAPIER.ColliderDesc.cuboid(0.0025, 0.07, 0.0025).setTranslation(0, 0.078, 0).setDensity(300), body);
        mesh = makeFlag();
      }
      mesh.traverse((m) => { if (m.isMesh) { m.castShadow = true; m.receiveShadow = true; m.userData.orig = m.material; } });
      castleGroup.add(mesh);
      const o = { kind, h: body.handle, col: col.handle, mesh, start: new THREE.Vector3(x, y, z), burning: false, burnT: 0, burnDur: 0, gone: false, down: false, scored: false };
      colToObj.set(col.handle, objs.length);
      objs.push(o);
    }
  }
  syncCastle(0);
}

function makeGuard(rng) {
  const g = new THREE.Group();
  const tunic = new THREE.MeshStandardMaterial({ color: new THREE.Color().setHSL(0.6 + rng() * 0.1, 0.55, 0.38), roughness: 0.8 });
  const body = new THREE.Mesh(new THREE.CylinderGeometry(0.011, 0.013, 0.036, 14), tunic); body.position.y = 0.018;
  const head = new THREE.Mesh(new THREE.SphereGeometry(0.011, 14, 10), new THREE.MeshStandardMaterial({ color: 0xf1c27d, roughness: 0.6 })); head.position.y = 0.047;
  const helm = new THREE.Mesh(new THREE.ConeGeometry(0.012, 0.016, 14), new THREE.MeshStandardMaterial({ color: 0xb8c0c8, metalness: 0.8, roughness: 0.3 })); helm.position.y = 0.06;
  const eyes = new THREE.Mesh(new THREE.BoxGeometry(0.012, 0.003, 0.002), new THREE.MeshBasicMaterial({ color: 0x111111 })); eyes.position.set(-0.0105, 0.048, 0); eyes.rotation.y = Math.PI / 2;
  const spear = new THREE.Mesh(new THREE.CylinderGeometry(0.0012, 0.0012, 0.08, 6), new THREE.MeshStandardMaterial({ color: 0x5a3d26 })); spear.position.set(0, 0.04, 0.016);
  g.add(body, head, helm, eyes, spear);
  return g;
}
function makeFlag() {
  const g = new THREE.Group();
  const base = new THREE.Mesh(new THREE.BoxGeometry(0.032, 0.008, 0.032), looks.wood); base.position.y = 0.004;
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.0022, 0.0022, 0.14, 8), new THREE.MeshStandardMaterial({ color: 0xcfb57a, metalness: 0.6, roughness: 0.4 })); pole.position.y = 0.078;
  const cloth = new THREE.Mesh(new THREE.PlaneGeometry(0.06, 0.04, 8, 4), new THREE.MeshStandardMaterial({ color: 0xd62828, side: THREE.DoubleSide, roughness: 0.8, emissive: 0x5a0000 }));
  cloth.position.set(0, 0.125, 0.03); cloth.rotation.y = Math.PI / 2; cloth.userData.cloth = true;
  g.add(base, pole, cloth);
  return g;
}

function syncCastle(time) {
  for (const o of objs) {
    if (o.gone) continue;
    const b = world.getRigidBody(o.h); if (!b) continue;
    const t = b.translation(), q = b.rotation();
    o.mesh.position.set(t.x, t.y, t.z); o.mesh.quaternion.set(q.x, q.y, q.z, q.w);
    if (o.kind === 'flag') {
      const cloth = o.mesh.children[2]; const pa = cloth.geometry.attributes.position;
      if (!cloth.userData.base) cloth.userData.base = pa.array.slice();
      const base = cloth.userData.base;
      for (let i = 0; i < pa.count; i++) { const x = base[i * 3]; pa.array[i * 3 + 2] = Math.sin(x * 90 + time * 6) * 0.004 * (x + 0.03) * 25; }
      pa.needsUpdate = true;
    }
  }
}

function objUp(o) { const b = world.getRigidBody(o.h); const q = b.rotation(); return new THREE.Vector3(0, 1, 0).applyQuaternion(new THREE.Quaternion(q.x, q.y, q.z, q.w)).y; }

function touching(c1, c2) {
  let hit = false;
  world.contactPair(c1, c2, (m) => { for (let i = 0; i < m.numContacts(); i++) if (m.contactDist(i) < 0.002) hit = true; });
  return hit;
}

function ignite(o, rng) {
  if (o.burning || o.gone) return;
  o.burning = true; o.burnT = 0; o.burnDur = 2.6 + rng() * 1.6;
  o.mesh.traverse((m) => { if (m.isMesh) { m.material = m.material.clone(); m.material.emissive = new THREE.Color(0xff4a00); m.material.emissiveIntensity = 0.3; } });
  S.shot && (S.shot.burned = (S.shot.burned || 0) + 1);
  if (!S.medals.has('fire')) medal('fire', 'Firestarter', 'Set the castle on fire');
}

// one fixed physics step for the active shot
function physStep() {
  const sh = S.shot;
  const mb = sh.marbleH != null ? world.getRigidBody(sh.marbleH) : null;
  if (mb) {
    const v = mb.linvel(); const s = Math.hypot(v.x, v.y, v.z); const k = 0.5 * 1.2 * 0.47 * Math.PI * MARBLE_R ** 2;
    mb.resetForces(true); mb.addForce({ x: -k * s * v.x, y: -k * s * v.y, z: -k * s * v.z }, true);
  }
  const prev = mb ? mb.translation() : null;
  world.step();
  sh.wt += DT; sh.steps++;
  if (mb) {
    const p = mb.translation();
    if (!sh.landed && p.y <= MARBLE_R + 0.0015) {
      const f = prev && prev.y !== p.y ? Math.max(0, Math.min(1, (prev.y - MARBLE_R) / (prev.y - p.y))) : 1;
      sh.land = new THREE.Vector3(prev.x + (p.x - prev.x) * f, 0, prev.z + (p.z - prev.z) * f);
      sh.landed = true; sh.landT = sh.wt; onLand();
    }
    if (p.y > sh.maxY) sh.maxY = p.y;
    if (!sh.landed) sh.flightT = sh.wt;
    // castle contacts every 3 steps
    if (objs.length && sh.steps % 3 === 0) {
      const mc = world.getCollider(sh.marbleCol);
      world.contactPairsWith(mc, (c2) => {
        const oi = colToObj.get(c2.handle); if (oi == null) return;
        if (!touching(mc, c2)) return;
        if (!sh.hit) { sh.hit = true; onCastleHit(); }
        if (S.ignite && sh.flaming) ignite(objs[oi], sh.rng);
      });
    }
    if (sh.flaming && sh.wt > 7) sh.flaming = false;
  }
  // fire spread / burn-out every 0.05 s
  if (sh.steps % 30 === 0) {
    for (let i = 0; i < objs.length; i++) {
      const o = objs[i]; if (!o.burning || o.gone) continue;
      o.burnT += 0.05;
      if (sh.steps % 120 === 0) {
        const c = world.getCollider(o.col);
        if (c) world.contactPairsWith(c, (c2) => { const j = colToObj.get(c2.handle); if (j != null && !objs[j].burning && sh.rng() < 0.045 && touching(c, c2)) ignite(objs[j], sh.rng); });
      }
      if (o.burnT >= o.burnDur) burnOut(o);
    }
  }
}

function burnOut(o) {
  const b = world.getRigidBody(o.h);
  const p = b.translation();
  for (let i = 0; i < 26; i++) {
    fire.emit(new THREE.Vector3(p.x, p.y, p.z), new THREE.Vector3((Math.random() - 0.5) * 0.6, Math.random() * 0.8, (Math.random() - 0.5) * 0.6), { life: 0.8 + Math.random() * 0.6, size: 0.006, grow: 0.5, c0: [1, 0.7, 0.2], c1: [0.6, 0.1, 0], grav: 1.5 });
  }
  for (let i = 0; i < 6; i++) smoke.emit(new THREE.Vector3(p.x, p.y, p.z), new THREE.Vector3((Math.random() - 0.5) * 0.05, 0.15, (Math.random() - 0.5) * 0.05), { life: 2.5, size: 0.05, grow: 3, alpha: 0.5, c0: [0.25, 0.22, 0.2], c1: [0.15, 0.15, 0.15] });
  world.removeRigidBody(b);
  o.gone = true; o.burning = false; o.mesh.visible = false;
}

function scoreCastle() {
  let blocks = 0, guards = 0, flag = false, total = 0;
  for (const o of objs) {
    let down = o.gone;
    if (!down) {
      const b = world.getRigidBody(o.h); const t = b.translation();
      const moved = Math.hypot(t.x - o.start.x, t.y - o.start.y, t.z - o.start.z);
      const up = objUp(o);
      if (o.kind === 'block') down = moved > 0.025 || Math.abs(up) < 0.9;
      else down = up < 0.55 || t.y < o.start.y - 0.05;
    }
    o.down = down;
    if (o.kind === 'block') { total++; if (down) blocks++; }
    else if (o.kind === 'guard' && down) guards++;
    else if (o.kind === 'flag' && down) flag = true;
  }
  const guardsTotal = objs.filter((o) => o.kind === 'guard').length;
  return { blocks, total, guards, guardsTotal, flag, points: blocks * 10 + guards * 100 + (flag ? 500 : 0), pct: total ? blocks / total : 0 };
}

// ---------- launching ----------
function launch() {
  if (!S.rig || S.rig.errors.length) { setTab('rig'); return toast('Not ready yet', S.rig ? S.rig.errors[0] : 'Load a launcher first.', true); }
  if (S.phase !== 'idle' && S.phase !== 'results') return;
  if (S.tab !== 'launch') setTab('launch');
  if (S.phase === 'results') finishWorld();
  if (S.round.used >= 3) { resetRound(); buildArena(); }
  audio.init();
  placement(true);
  const sim = getSim();
  S.snap = { world: world.takeSnapshot(), objs: objs.map((o) => ({ burning: o.burning, burnT: o.burnT, burnDur: o.burnDur, gone: o.gone })), score: S.round.score, used: S.round.used };
  startShot(sim);
}

function startShot(sim) {
  S.round.used++;
  const sh = S.shot = {
    sim, t: -0.7, wt: 0, steps: 0, cut: true, released: false, landed: false, hit: false, maxY: 0, flightT: 0, flaming: S.ignite,
    rng: mulberry(S.round.seed * 31 + S.round.used), marbleH: null, marbleCol: null, acc: 0, trail: [], resultShown: false,
    design: ($('#designName').value || '').trim() || S.L.name.replace(/^Sample:\s*/, ''),
  };
  S.phase = 'launch';
  controls.enabled = false;
  $('#results').classList.remove('show');
  marble.visible = true;
  marbleMat.emissive.set(S.ignite ? 0xff5a00 : 0x000000); marbleMat.emissiveIntensity = S.ignite ? 1.2 : 0;
  // trail
  const tg = new THREE.BufferGeometry(); tg.setAttribute('position', new THREE.BufferAttribute(new Float32Array(3 * 4000), 3)); tg.setDrawRange(0, 0);
  const tl = new THREE.Line(tg, new THREE.LineBasicMaterial({ color: [0xffb347, 0x56c2ff, 0x6fd38a][(S.round.used - 1) % 3], transparent: true, opacity: 0.9 }));
  tl.frustumCulled = false; tl.visible = S.trail; scene.add(tl); trails.push(tl); sh.trailLine = tl;
  audio.creak();
  updateLaunchUI();
  $('#hud').style.display = 'block'; $('#hudSm').textContent = S.mode === 'siege' ? 'Siege engine armed' : 'Ready…'; $('#hudBig').textContent = 'FIRE!';
}

function releaseMarble() {
  const sh = S.shot, sim = sh.sim;
  const p = sim.pos.clone().applyMatrix4(launcherRoot.matrix);
  const v = sim.vel.clone().transformDirection(launcherRoot.matrix).multiplyScalar(sim.vel.length());
  const body = world.createRigidBody(RAPIER.RigidBodyDesc.dynamic().setTranslation(p.x, p.y, p.z).setLinvel(v.x, v.y, v.z).setCcdEnabled(true).setAngularDamping(2.5).setLinearDamping(0.05));
  const col = world.createCollider(RAPIER.ColliderDesc.ball(MARBLE_R).setDensity(MARBLE_M / ((4 / 3) * Math.PI * MARBLE_R ** 3)).setFriction(0.5).setRestitution(0.45), body);
  sh.marbleH = body.handle; sh.marbleCol = col.handle; sh.released = true; sh.relPos = p.clone(); sh.maxY = p.y;
  audio.thwack(sim.speed);
  if (sim.fizzle) toast('Fizzle!', 'The arm never reached its stop or release. Check bands, counterweight and angles.', true);
}

function onLand() {
  const sh = S.shot; audio.thud();
  // dust puff
  for (let i = 0; i < 18; i++) smoke.emit(sh.land.clone().setY(0.01), new THREE.Vector3((Math.random() - 0.5) * 0.4, Math.random() * 0.25, (Math.random() - 0.5) * 0.4), { life: 1.2, size: 0.03, grow: 2.5, alpha: 0.5, c0: [0.55, 0.45, 0.35], c1: [0.4, 0.35, 0.3], drag: 2 });
  if (sh.flaming) for (let i = 0; i < 30; i++) fire.emit(sh.land.clone().setY(0.01), new THREE.Vector3((Math.random() - 0.5) * 1.2, Math.random() * 1.2, (Math.random() - 0.5) * 1.2), { life: 0.6, size: 0.01, grow: 0.3, grav: 3, c0: [1, 0.8, 0.3], c1: [1, 0.2, 0] });
}
function onCastleHit() { audio.crash(); banner('DIRECT HIT!', 'the castle shakes'); }

function replay() {
  if (!S.snap || !S.shot) return toast('Nothing to replay', 'Launch first!', true);
  const sim = S.shot.sim;
  world.free(); world = RAPIER.World.restoreSnapshot(S.snap.world);
  world.timestep = DT; world.lengthUnit = 0.05; world.numSolverIterations = 8;
  objs.forEach((o, i) => {
    const s = S.snap.objs[i]; Object.assign(o, s);
    o.mesh.visible = !o.gone;
    if (!o.burning) o.mesh.traverse((m) => { if (m.isMesh && m.userData.orig) m.material = m.userData.orig; });
  });
  S.round.score = S.snap.score; S.round.used = S.snap.used;
  const t = trails.pop(); if (t) scene.remove(t);
  pinsGroup.children.slice(-1).forEach((c) => pinsGroup.remove(c));
  fire.clear();
  S.phase = 'idle';
  startShot(sim);
  S.shot.isReplay = true;
}

function skipShot() {
  if (!S.shot || S.phase === 'idle') return;
  while (S.phase !== 'idle') { stepShot(1 / 30, true); }
  controls.enabled = true;
  if (S.tab === 'launch' && S.shot.land) {
    const c = S.mode === 'siege' && S.shot.hit ? new THREE.Vector3(S.tgtFt * FT + 0.12, 0.12, 0) : S.shot.land.clone();
    tweenCam(c.clone().add(new THREE.Vector3(-0.85, 0.55, 1.05)), c);
  }
}

function finishWorld() {
  // fast-forward remaining world time of the last shot so later shots stay deterministic
  const sh = S.shot; if (!sh) return;
  while (sh.wt < POST_CAP) physStep();
  S.phase = 'idle';
}

// advance shot by dt seconds of *sim* time
function stepShot(sdt, fast = false) {
  const sh = S.shot; const sim = sh.sim;
  sh.t += sdt;
  // arm
  const st = sim.stride, nF = sim.frames.length / st;
  const fi = Math.max(0, Math.min(nF - 1, sh.t * 1000));
  const i0 = Math.floor(fi), i1 = Math.min(nF - 1, i0 + 1), fr = fi - i0;
  const th = sim.frames[i0 * st + 1] * (1 - fr) + sim.frames[i1 * st + 1] * fr;
  const mx = sim.frames[i0 * st + 3] * (1 - fr) + sim.frames[i1 * st + 3] * fr;
  const my = sim.frames[i0 * st + 4] * (1 - fr) + sim.frames[i1 * st + 4] * fr;
  setArm(th); updateBands(th);
  const r = S.rig;
  const z = r.holder === 'cup' ? r.cup.z : r.sl.z;
  const rideM = r.fromPlane(mx, my, z).applyMatrix4(launcherRoot.matrix);
  if (r.holder === 'sling') drawSling(modelToWorld(S.L.sling.attach, true, th), rideM);
  if (!sh.released) {
    marble.position.copy(rideM);
    if (sh.t >= sim.releaseT) releaseMarble();
  }
  if (sh.released) {
    const target = Math.min(sh.t - sim.releaseT, POST_CAP);
    while (sh.wt + DT <= target) physStep();
    const mb = world.getRigidBody(sh.marbleH);
    if (mb) {
      const p = mb.translation(); marble.position.set(p.x, p.y, p.z);
      const q = mb.rotation(); marble.quaternion.set(q.x, q.y, q.z, q.w);
      if (!sh.landed || sh.wt - sh.landT < 0.4) {
        const g = sh.trailLine.geometry; const n = g.drawRange.count;
        if (n < 4000) { g.attributes.position.setXYZ(n, p.x, p.y, p.z); g.setDrawRange(0, n + 1); g.attributes.position.needsUpdate = true; }
      }
    }
  }
  // HUD
  if (!fast) {
    if (sh.released) {
      const x = Math.max(0, sh.landed ? sh.land.x : marble.position.x);
      $('#hudBig').textContent = ftIn(x);
      $('#hudSm').textContent = sh.landed ? (sh.hit ? 'Hit! Landed at' : S.mode === 'siege' ? (sh.land.x > S.tgtFt * FT ? 'Overshot the castle' : 'Short of the castle') : 'Landed') : `${mph(sh.sim.speed).toFixed(1)} mph launch · ${ftIn(marble.position.y)} high`;
    }
  }
  // phases
  if (S.phase === 'launch' && sh.released && sh.t > sim.releaseT + 0.06) S.phase = 'flight';
  if (S.phase === 'flight' && (sh.landed || sh.wt > 6)) {
    if (!sh.landed) { sh.landed = true; sh.land = marble.position.clone().setY(0); sh.landT = sh.wt; }
    S.phase = 'impact';
  }
  const hold = S.mode === 'siege' ? (sh.hit ? 4.2 : 2.2) : 1.8;
  if (S.phase === 'impact' && sh.wt - sh.landT > hold && !sh.resultShown) { sh.resultShown = true; showResults(fast); S.phase = 'results'; controls.enabled = true; }
  if (S.phase === 'results' && sh.wt >= POST_CAP - 1e-9) { S.phase = 'idle'; }
  if (fast && S.phase === 'results') finishWorld();
}

function timeScale() {
  const sh = S.shot; if (!sh) return 1;
  if (S.phase === 'launch') return sh.t < 0 ? 1 : S.slowmo ? 0.12 : 1;
  if (S.phase === 'flight') return S.slowmo ? 0.75 : 1;
  if (S.phase === 'impact') return sh.hit && sh.wt - sh.landT < 0.5 && S.slowmo ? 0.35 : 1;
  return 1;
}

// ---------- results ----------
function showResults(fast) {
  const sh = S.shot, sim = sh.sim;
  const distM = sh.land.x; const r = S.round;
  let title = ftIn(distM), sub = `${distM.toFixed(2)} m`, extra = [], score = 0, accIn = null;
  const D = S.tgtFt * FT;
  if (S.mode === 'target') {
    const miss = Math.hypot(sh.land.x - D, sh.land.z) / IN; accIn = miss;
    score = miss <= 3 ? 100 : miss <= 6 ? 50 : miss <= 12 ? 25 : miss <= 18 ? 10 : miss <= 24 ? 5 : 0;
    title = score === 100 ? 'BULLSEYE!' : score ? `+${score} points` : 'Missed';
    sub = `${miss.toFixed(1)} in from center · landed ${ftIn(distM)}`;
    if (score === 100) { banner('BULLSEYE!', 'dead center'); medal('bull', 'Sharpshooter', 'Hit a bullseye'); audio.fanfare(); }
    extra.push(['Off target', miss.toFixed(1) + ' in'], ['Short / long', ((sh.land.x - D) / IN).toFixed(1) + ' in']);
  } else if (S.mode === 'siege') {
    const sc = scoreCastle(); const gained = sc.points - r.score; r.score = sc.points; score = gained;
    title = sc.flag && !r.captured ? 'CASTLE CAPTURED!' : gained > 0 ? `+${gained} points` : sh.hit ? 'Glancing blow' : 'Missed the castle';
    sub = `${sc.blocks}/${sc.total} blocks down · ${sc.guards}/${sc.guardsTotal} guards · ${sh.burned || 0} set ablaze`;
    if (sc.flag && !r.captured) { r.captured = true; banner('CASTLE CAPTURED!', 'the banner falls'); medal('flag', 'Conqueror', 'Captured the banner'); audio.fanfare(); }
    if (sc.blocks >= 10) medal('wall', 'Wall Breaker', '10+ blocks toppled');
    if (sc.pct >= 0.75) medal('rubble', 'Reduced to Rubble', '75% of a castle destroyed');
    extra.push(['Castle destroyed', Math.round(sc.pct * 100) + '%'], ['Round score', r.score]);
    if (!sh.hit) { const off = (sh.land.x - (D - 0.06)) / IN; sub += ` · ${off < 0 ? 'short by ' + ftIn(-off * IN) : 'long by ' + ftIn(off * IN)}`; }
  }
  const stats = [
    ['Distance', ftIn(distM)], ['Launch speed', `${sim.speed.toFixed(2)} m/s`], ['Launch angle', `${deg(sim.angle).toFixed(1)}°`], ['Max height', ftIn(sh.maxY)],
    ['Hang time', `${sh.flightT.toFixed(2)} s`], ['Energy → marble', `${Math.round(sim.stats.efficiency * 100)}%`], ...extra,
  ].slice(0, 8);
  // record
  const best = Math.max(0, ...S.log.filter((l) => l.mode === S.mode && S.mode === 'distance').map((l) => l.distM));
  if (S.mode === 'distance' && S.log.some((l) => l.mode === 'distance') && distM > best + 0.005 && !sh.isReplay) { banner('NEW RECORD!', ftIn(distM)); audio.fanfare(); }
  if (!sh.isReplay) {
    S.log.push({ n: S.log.length + 1, design: sh.design, mode: S.mode, distM: +distM.toFixed(4), speed: +sim.speed.toFixed(3), angle: +deg(sim.angle).toFixed(1), maxH: +sh.maxY.toFixed(3), score, accIn: accIn != null ? +accIn.toFixed(1) : null, eff: Math.round(sim.stats.efficiency * 100), when: new Date().toLocaleString() });
    saveLocal(); renderLog();
  }
  medal('first', 'First Launch', 'Your siege engine works!');
  if (distM >= 10 * FT) medal('ten', 'Ten-Footer', 'Launched 10 ft or more');
  if (distM >= 20 * FT) medal('twenty', 'Twenty-Footer', 'Launched 20 ft or more');
  if (distM >= 30 * FT) medal('thirty', 'Thirty-Footer', 'Launched 30 ft or more');
  if (new Set(S.log.map((l) => l.design)).size >= 4) medal('iter', 'Iterator', 'Tested 4 different designs');
  // pin
  const pin = new THREE.Group();
  const pole = new THREE.Mesh(new THREE.CylinderGeometry(0.003, 0.003, 0.16, 6), new THREE.MeshStandardMaterial({ color: 0xeeeeee }));
  pole.position.y = 0.08; pin.add(pole);
  const lab = sprite(ftIn(distM), { scale: 0.28 }); lab.position.y = 0.2; pin.add(lab);
  pin.position.copy(sh.land); pinsGroup.add(pin);
  const done = S.round.used >= 3;
  $('#results').innerHTML = `<div class="head"><div class="title">${title}</div><div class="sub">${sub}</div></div>
    <div class="grid">${stats.map(([a, b]) => `<div class="stat"><small>${a}</small><b>${b}</b></div>`).join('')}</div>
    <div class="act"><span class="kbd" style="margin-right:auto;align-self:center">Launch ${r.used} of 3${done ? ' · round over' : ''}${S.mode === 'siege' ? ` · round score ${r.score}` : ''}</span>
    <button class="btn" id="rTweak">🔧 Tweak design</button><button class="btn" id="rReplay">↺ Replay</button><button class="btn primary" id="rAgain">${done ? '⟳ New round' : '🔥 Launch again'}</button></div>`;
  const pw = $('#panel').classList.contains('collapsed') || innerWidth <= 820 ? 0 : $('#panel').offsetWidth + 12;
  $('#results').style.left = `calc(50% + ${pw / 2}px)`;
  $('#results').classList.add('show');
  $('#rTweak').onclick = () => { $('#results').classList.remove('show'); setTab('rig'); $('#stMotion').open = true; };
  $('#rReplay').onclick = () => { $('#results').classList.remove('show'); replay(); };
  $('#rAgain').onclick = () => { $('#results').classList.remove('show'); launch(); };
  $('#hud').style.display = 'none';
  updateLaunchUI();
  if (done && S.mode === 'siege') toast('Round complete', `Final score: ${r.score}`);
}

function renderLog() {
  const tb = $('#logTable tbody');
  tb.innerHTML = [...S.log].reverse().map((l) => `<tr><td>${l.n}</td><td>${esc(l.design)}</td><td>${l.mode}</td><td class="num">${ftIn(l.distM)}</td><td class="num">${l.speed.toFixed(1)}</td><td class="num">${l.angle}°</td><td class="num">${l.mode === 'distance' ? '–' : l.score}</td></tr>`).join('') || '<tr><td colspan="7" class="kbd">No launches yet.</td></tr>';
}
function csv() {
  const head = 'shot,design,mode,distance_ft,distance_m,launch_speed_mps,launch_angle_deg,max_height_m,efficiency_pct,target_miss_in,score,time';
  return [head, ...S.log.map((l) => [l.n, `"${String(l.design).replace(/"/g, '""')}"`, l.mode, (l.distM / FT).toFixed(2), l.distM, l.speed, l.angle, l.maxH, l.eff, l.accIn ?? '', l.score, `"${l.when}"`].join(','))].join('\n');
}
$('#copyCsv').onclick = async () => { try { await navigator.clipboard.writeText(csv()); $('#csvMsg').textContent = 'Copied! Paste into Google Sheets.'; } catch { $('#csvMsg').textContent = 'Copy was blocked. Select and copy the table instead.'; } };
$('#dlCsv').onclick = () => { try { const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([csv()], { type: 'text/csv' })); a.download = 'siegeready-log.csv'; a.click(); } catch { $('#csvMsg').textContent = 'Download blocked here — use Copy CSV.'; } };
$('#clearLog').onclick = () => { S.log = []; saveLocal(); renderLog(); };

// ---------- toasts / banner / medals ----------
function toast(t, s, warn) {
  const d = document.createElement('div'); d.className = 'toast'; if (warn) d.style.borderColor = '#ff5b4a';
  d.innerHTML = `<b>${esc(t)}</b><small>${esc(s || '')}</small>`; $('#toasts').append(d);
  setTimeout(() => { d.style.transition = '.4s'; d.style.opacity = 0; setTimeout(() => d.remove(), 400); }, 3800);
}
function medal(id, t, s) { if (S.medals.has(id)) return; S.medals.add(id); saveLocal(); toast('🏅 ' + t, s); audio.ding(); }
let bannerTimer;
function banner(b, s) { $('#bannerB').textContent = b; $('#bannerS').textContent = s; $('#banner').classList.add('show'); clearTimeout(bannerTimer); bannerTimer = setTimeout(() => $('#banner').classList.remove('show'), 1600); }

// ---------- audio ----------
const audio = {
  ctx: null, crackleT: 0,
  init() { if (!this.ctx) { try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); } catch { /* none */ } } if (this.ctx?.state === 'suspended') this.ctx.resume(); },
  noise(dur, f, q, gain, type = 'bandpass', t0 = 0) {
    const c = this.ctx; if (!c || !S.sound) return;
    const b = c.createBuffer(1, Math.max(1, c.sampleRate * dur), c.sampleRate); const d = b.getChannelData(0);
    for (let i = 0; i < d.length; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / d.length) ** 2;
    const s = c.createBufferSource(); s.buffer = b; const fl = c.createBiquadFilter(); fl.type = type; fl.frequency.value = f; fl.Q.value = q;
    const g = c.createGain(); g.gain.value = gain; s.connect(fl).connect(g).connect(c.destination); s.start(c.currentTime + t0);
  },
  tone(f, dur, gain, type = 'sine', t0 = 0, f2) {
    const c = this.ctx; if (!c || !S.sound) return;
    const o = c.createOscillator(); o.type = type; o.frequency.setValueAtTime(f, c.currentTime + t0); if (f2) o.frequency.exponentialRampToValueAtTime(f2, c.currentTime + t0 + dur);
    const g = c.createGain(); g.gain.setValueAtTime(gain, c.currentTime + t0); g.gain.exponentialRampToValueAtTime(0.001, c.currentTime + t0 + dur);
    o.connect(g).connect(c.destination); o.start(c.currentTime + t0); o.stop(c.currentTime + t0 + dur + 0.05);
  },
  creak() { this.tone(140, 0.35, 0.05, 'sawtooth', 0, 90); },
  thwack(v) { this.noise(0.12, 900, 1, 0.5); this.tone(110, 0.25, 0.4, 'sine', 0, 50); this.noise(0.6, 2500, 0.5, 0.12 + Math.min(v, 12) * 0.01, 'bandpass', 0.05); },
  thud() { this.tone(70, 0.3, 0.35, 'sine', 0, 40); this.noise(0.15, 400, 1, 0.25); },
  crash() { this.noise(0.5, 700, 0.6, 0.5); this.tone(90, 0.5, 0.3, 'triangle', 0, 45); },
  ding() { this.tone(880, 0.25, 0.08, 'triangle'); this.tone(1320, 0.35, 0.06, 'triangle', 0.08); },
  fanfare() { [523, 659, 784, 1047].forEach((f, i) => this.tone(f, 0.35, 0.09, 'square', i * 0.11)); },
  crackle(n) { if (!this.ctx || !S.sound || n <= 0) return; this.noise(0.03, 3000 + Math.random() * 3000, 2, Math.min(0.12, 0.02 + n * 0.006), 'highpass'); },
};
$('#btnSound').onclick = () => { S.sound = !S.sound; $('#btnSound').textContent = S.sound ? '🔊 Sound' : '🔇 Muted'; audio.init(); };
$('#btnPanel').onclick = () => { $('#panel').classList.toggle('collapsed'); resize(); };
$('#btnHelp').onclick = () => $('#help').classList.add('show');
$('#helpClose').onclick = () => $('#help').classList.remove('show');

// ---------- main loop ----------
let lastT = performance.now();
let elapsed = 0;
function resize() {
  const w = innerWidth, h = innerHeight; renderer.setSize(w, h, false); camera.aspect = w / h;
  const panelOpen = !$('#panel').classList.contains('collapsed') && w > 700;
  const off = panelOpen ? $('#panel').offsetWidth + 12 : 0;
  if (off) camera.setViewOffset(w, h, -off / 2, 0, w, h); else camera.clearViewOffset();
  camera.updateProjectionMatrix();
}
addEventListener('resize', resize); resize();

const tmpV = new THREE.Vector3();
const CHAR = new THREE.Color(0x1a1410);
function frame() {
  requestAnimationFrame(frame);
  const now = performance.now(); const dt = Math.min((now - lastT) / 1000, 0.05); lastT = now; elapsed += dt;
  let sdt = dt;
  if (S.shot && S.phase !== 'idle') { sdt = dt * timeScale(); stepShot(sdt); }
  // camera choreography
  if (S.shot && S.phase !== 'idle' && S.phase !== 'results') {
    camTween = null;
    const sh = S.shot; let pos, look;
    const lc = new THREE.Vector3(-0.12, 0.12, 0);
    if (S.phase === 'launch') { pos = lc.clone().add(new THREE.Vector3(0.18, 0.08, 0.62)); look = lc; }
    else if (S.phase === 'flight') {
      const m = marble.position; pos = new THREE.Vector3(m.x - 0.55, Math.max(0.25, m.y + 0.18), 1.25 + m.x * 0.12); look = m.clone();
    } else {
      const c = S.mode === 'siege' && sh.hit ? new THREE.Vector3(S.tgtFt * FT + 0.12, 0.15, 0) : sh.land.clone();
      pos = c.clone().add(new THREE.Vector3(-0.85, 0.55, 1.05)); look = c;
    }
    let k = S.phase === 'launch' ? 0.3 : 1 - Math.pow(0.002, dt);
    if (sh.cut) { k = 1; sh.cut = false; }
    camera.position.lerp(pos, k); controls.target.lerp(look, k);
    aimSun(controls.target, S.phase === 'flight' ? 1.6 : 1.0);
  } else if (camTween) {
    camTween.k = Math.min(1, camTween.k + dt / camTween.dur); const e = 1 - (1 - camTween.k) ** 3;
    camera.position.lerpVectors(camTween.p0, camTween.p1, e); controls.target.lerpVectors(camTween.t0, camTween.t1, e);
    if (camTween.k >= 1) camTween = null;
  }
  if (S.phase === 'results' && S.shot) { aimSun(controls.target, 1.0); }
  controls.update();
  camera.lookAt(controls.target);
  // castle + fire visuals
  if (world && objs.length) syncCastle(elapsed);
  let nBurn = 0; const cen = new THREE.Vector3();
  for (const o of objs) {
    if (!o.burning || o.gone) continue;
    nBurn++; cen.add(o.mesh.position);
    const k = o.burnT / o.burnDur;
    o.mesh.traverse((m) => { if (m.isMesh && m.material.emissive) { m.material.emissiveIntensity = 0.4 + Math.random() * 0.5; m.material.color.lerp(CHAR, 0.01); } });
    if (Math.random() < 0.9 * dt * 60) {
      const p = o.mesh.position;
      fire.emit(new THREE.Vector3(p.x + (Math.random() - 0.5) * 0.06, p.y + 0.01, p.z + (Math.random() - 0.5) * 0.06), new THREE.Vector3((Math.random() - 0.5) * 0.03, 0.18 + Math.random() * 0.15, (Math.random() - 0.5) * 0.03),
        { life: 0.5 + Math.random() * 0.4, size: 0.03 + 0.03 * (1 - k), grow: 0.2, alpha: 0.9, c0: [1, 0.75, 0.3], c1: [0.9, 0.15, 0.02] });
      if (Math.random() < 0.25) smoke.emit(new THREE.Vector3(p.x, p.y + 0.06, p.z), new THREE.Vector3((Math.random() - 0.5) * 0.03, 0.12, 0.02), { life: 2.5, size: 0.04, grow: 4, alpha: 0.35, c0: [0.2, 0.18, 0.17], c1: [0.3, 0.3, 0.3] });
    }
  }
  fireLight.intensity = nBurn ? Math.min(3, 0.5 + nBurn * 0.25) * (0.8 + Math.random() * 0.4) : 0;
  if (nBurn) fireLight.position.copy(cen.multiplyScalar(1 / nBurn)).add(new THREE.Vector3(-0.1, 0.12, 0));
  audio.crackleT -= dt; if (nBurn && audio.crackleT <= 0) { audio.crackle(nBurn); audio.crackleT = 0.03 + Math.random() * 0.12; }
  // marble flame
  const flaming = S.ignite && S.shot && S.phase !== 'idle' && S.shot.flaming || (S.ignite && S.view === 'field' && S.phase === 'idle' && S.L);
  marbleLight.intensity = flaming && marble.visible ? 1.2 + Math.random() * 0.6 : 0;
  marbleLight.position.copy(marble.position).add(tmpV.set(0, 0.02, 0));
  marbleMat.emissive.set(flaming ? 0xff5a00 : 0x000000); marbleMat.emissiveIntensity = flaming ? 0.9 : 0;
  if (flaming && marble.visible) {
    const n = S.phase === 'flight' ? 6 : 2;
    for (let i = 0; i < n; i++) fire.emit(marble.position.clone().add(tmpV.set((Math.random() - 0.5) * 0.008, (Math.random() - 0.5) * 0.008, (Math.random() - 0.5) * 0.008)),
      new THREE.Vector3((Math.random() - 0.5) * 0.04, 0.12 + Math.random() * 0.1, (Math.random() - 0.5) * 0.04), { life: 0.35 + Math.random() * 0.25, size: 0.022, grow: 0.15, c0: [1, 0.85, 0.4], c1: [1, 0.2, 0] });
  }
  // torches
  if (S.view === 'field') for (const t of torches) if (Math.random() < 0.7) fire.emit(t.clone().add(tmpV.set((Math.random() - 0.5) * 0.03, 0, (Math.random() - 0.5) * 0.03)), new THREE.Vector3(0, 0.25 + Math.random() * 0.2, 0), { life: 0.5, size: 0.07, grow: 0.2, c0: [1, 0.75, 0.3], c1: [0.9, 0.2, 0.0] });
  const ps = renderer.domElement.height / (2 * Math.tan((camera.fov * Math.PI) / 360));
  fire.mat.uniforms.scale.value = smoke.mat.uniforms.scale.value = ps;
  fire.update(sdt); smoke.update(sdt);
  if (S.view === 'rig') marble.rotation.y += dt * 0.5;
  renderer.render(scene, camera);
}

// ---------- boot ----------
(async function boot() {
  await RAPIER.init();
  newWorld();
  buildArena();
  loadLauncher(sampleCatapult()); markSample('#sampleCat');
  renderLog(); updateLaunchUI();
  $('#loading').remove();
  frame();
  window.__siege = { S, launch, setTab, getSim, skipShot, replay, scoreCastle, objs, handleFiles, loadLauncher, sampleTrebuchet, sampleCatapult, camera, controls, exportGLB: () => new Promise((res) => {
    const root = new THREE.Scene(); for (const p of S.L.parts) { const m = new THREE.Mesh(p.geom, new THREE.MeshStandardMaterial({ color: MATERIALS[p.material].color })); m.name = p.name; root.add(m); }
    new GLTFExporter().parse(root, (buf) => res(buf), () => res(null), { binary: true });
  }) };
})();
