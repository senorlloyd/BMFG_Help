// SiegeReady physics core: mass properties from meshes + launcher dynamics.
// All lengths in meters, masses in kg, angles in radians unless named *Deg.
import * as THREE from 'three';

export const G = 9.81;
export const MARBLE_R = 0.008; // 16 mm glass marble
export const MARBLE_M = 2500 * (4 / 3) * Math.PI * MARBLE_R ** 3; // ~5.36 g
export const IN = 0.0254;

export const MATERIALS = {
  plywood: { label: 'Plywood (birch)', density: 680, color: 0xd8b07a, wood: true },
  mdf: { label: 'MDF', density: 750, color: 0xb08a5a, wood: true },
  pine: { label: 'Pine / dowel', density: 500, color: 0xe4c48c, wood: true },
  pla: { label: 'PLA (3D printed)', density: 1240, color: 0xff7a1a, printed: true },
  petg: { label: 'PETG (3D printed)', density: 1270, color: 0x27b3c9, printed: true },
  acrylic: { label: 'Acrylic', density: 1180, color: 0x9fd6ff },
  steel: { label: 'Steel (bolts, washers, rod)', density: 7850, color: 0x9aa3ad, metal: true },
  pennies: { label: 'Pennies / coins stack', density: 7140, color: 0xc77b3a, metal: true },
  lead: { label: 'Lead fishing weights', density: 11340, color: 0x5d636b, metal: true },
  sand: { label: 'Sand-filled', density: 1600, color: 0xd9c38f },
  rubber: { label: 'Rubber / foam', density: 1100, color: 0x333333 },
  massless: { label: 'Weightless (ignore mass)', density: 0, color: 0xcccccc },
};

export function effectiveDensity(matKey, infillPct) {
  const m = MATERIALS[matKey] || MATERIALS.plywood;
  if (m.printed) {
    // walls/top/bottom shells ~30% of a small part, rest at infill %
    const f = 0.3 + 0.7 * (Math.max(0, Math.min(100, infillPct ?? 20)) / 100);
    return m.density * f;
  }
  return m.density;
}

// Volume, center of mass and inertia (per unit density) of a closed triangle mesh.
// Returns {vol, com:V3, C:[xx,yy,zz,xy,xz,yz] second moments about origin per unit density, ok}
export function geomMoments(geoms) {
  let vol = 0, cx = 0, cy = 0, cz = 0;
  let xx = 0, yy = 0, zz = 0, xy = 0, xz = 0, yz = 0;
  const box = new THREE.Box3();
  for (const g of geoms) {
    const pos = g.attributes.position.array;
    const idx = g.index ? g.index.array : null;
    const n = idx ? idx.length : pos.length / 3;
    g.computeBoundingBox();
    box.union(g.boundingBox);
    for (let t = 0; t < n; t += 3) {
      const i0 = (idx ? idx[t] : t) * 3, i1 = (idx ? idx[t + 1] : t + 1) * 3, i2 = (idx ? idx[t + 2] : t + 2) * 3;
      const ax = pos[i0], ay = pos[i0 + 1], az = pos[i0 + 2];
      const bx = pos[i1], by = pos[i1 + 1], bz = pos[i1 + 2];
      const qx = pos[i2], qy = pos[i2 + 1], qz = pos[i2 + 2];
      const det = ax * (by * qz - bz * qy) - ay * (bx * qz - bz * qx) + az * (bx * qy - by * qx);
      vol += det / 6;
      const sx = ax + bx + qx, sy = ay + by + qy, sz = az + bz + qz;
      cx += det * sx / 24; cy += det * sy / 24; cz += det * sz / 24;
      const k = det / 120;
      xx += k * (ax * ax + bx * bx + qx * qx + sx * sx);
      yy += k * (ay * ay + by * by + qy * qy + sy * sy);
      zz += k * (az * az + bz * bz + qz * qz + sz * sz);
      xy += k * (ax * ay + bx * by + qx * qy + sx * sy);
      xz += k * (ax * az + bx * bz + qx * qz + sx * sz);
      yz += k * (ay * az + by * bz + qy * qz + sy * sz);
    }
  }
  if (vol < 0) { vol = -vol; cx = -cx; cy = -cy; cz = -cz; xx = -xx; yy = -yy; zz = -zz; xy = -xy; xz = -xz; yz = -yz; }
  const size = box.getSize(new THREE.Vector3());
  const boxVol = size.x * size.y * size.z;
  const ok = vol > 1e-10 && vol <= boxVol * 1.02;
  if (!ok) {
    // Open / broken mesh: fall back to a solid box at 50% fill
    const v = Math.max(boxVol * 0.5, 1e-9);
    const c = box.getCenter(new THREE.Vector3());
    const a = size.x, b = size.y, h = size.z;
    // second moments of a box about its center, scaled to v (uniform density)
    const sxx = v * a * a / 12, syy = v * b * b / 12, szz = v * h * h / 12;
    return {
      vol: v, com: c, ok: false,
      C: [sxx + v * c.x * c.x, syy + v * c.y * c.y, szz + v * c.z * c.z, v * c.x * c.y, v * c.x * c.z, v * c.y * c.z],
    };
  }
  return { vol, com: new THREE.Vector3(cx / vol, cy / vol, cz / vol), C: [xx, yy, zz, xy, xz, yz], ok: true };
}

// Inertia about an axis (unit vector a) through point p, for a body of density rho with moments M.
export function inertiaAboutAxis(M, rho, p, a) {
  const [xx, yy, zz, xy, xz, yz] = M.C;
  // second moment tensor about p: C_p = C - (p c^T + c p^T) vol + vol p p^T
  const v = M.vol, c = M.com;
  const Cp = [
    xx - 2 * p.x * c.x * v + v * p.x * p.x,
    yy - 2 * p.y * c.y * v + v * p.y * p.y,
    zz - 2 * p.z * c.z * v + v * p.z * p.z,
    xy - (p.x * c.y + c.x * p.y) * v + v * p.x * p.y,
    xz - (p.x * c.z + c.x * p.z) * v + v * p.x * p.z,
    yz - (p.y * c.z + c.y * p.z) * v + v * p.y * p.z,
  ];
  // I_a = a^T (tr(C) I - C) a = tr(C) - a^T C a
  const tr = Cp[0] + Cp[1] + Cp[2];
  const aCa = a.x * a.x * Cp[0] + a.y * a.y * Cp[1] + a.z * a.z * Cp[2] + 2 * (a.x * a.y * Cp[3] + a.x * a.z * Cp[4] + a.y * a.z * Cp[5]);
  return rho * (tr - aCa);
}

export const FRICTION = { none: 0, low: 0.12, medium: 0.3, high: 0.6 };
const AXLE_R = 0.004;

// ---------------------------------------------------------------------------
// Build the reduced (planar) rig description from a launcher definition.
// launcher: { parts:[{geoms, role, material, infill, moments}], pivot:V3, axis:'x'|'z',
//   holder:'cup'|'sling', cup:V3, sling:{attach:V3, lengthIn}, bands:[{p1,p1Arm,p2,p2Arm,count,restIn,kNpm}],
//   cockDeg, stopDeg, releaseDeg, friction }
export function buildRig(L) {
  const errors = [];
  const armParts = L.parts.filter((p) => p.role === 'arm');
  const baseParts = L.parts.filter((p) => p.role === 'base');
  if (!armParts.length) errors.push('Mark at least one part as the swinging Arm.');
  if (!baseParts.length) errors.push('Mark at least one part as the fixed Frame.');
  if (!L.pivot) errors.push('Pick the pivot (axle) point.');
  if (L.holder === 'cup' && !L.cup) errors.push('Pick where the marble sits in the cup.');
  if (L.holder === 'sling' && !(L.sling && L.sling.attach)) errors.push('Pick the sling attachment point on the arm.');
  if (errors.length) return { errors };

  const a = L.axis === 'x' ? new THREE.Vector3(1, 0, 0) : new THREE.Vector3(0, 0, 1);
  const e2 = new THREE.Vector3(0, 1, 0);
  const e1 = new THREE.Vector3().crossVectors(e2, a); // (e1,e2,a) right-handed
  const p = L.pivot.clone();
  const toPlane = (q) => { const d = q.clone().sub(p); return { x: d.dot(e1), y: d.dot(e2), z: d.dot(a) }; };
  const fromPlane = (x, y, z) => p.clone().addScaledVector(e1, x).addScaledVector(e2, y).addScaledVector(a, z);

  let M = 0, I = 0, mx = 0, my = 0;
  for (const part of armParts) {
    const rho = effectiveDensity(part.material, part.infill);
    const mass = rho * part.moments.vol;
    if (mass <= 0) continue;
    const c = toPlane(part.moments.com);
    M += mass; mx += mass * c.x; my += mass * c.y;
    I += inertiaAboutAxis(part.moments, rho, p, a);
  }
  const cX = M > 0 ? mx / M : 0, cY = M > 0 ? my / M : 0;
  const polar = (q) => { const c = toPlane(q); return { rho: Math.hypot(c.x, c.y), alpha: Math.atan2(c.y, c.x), z: c.z }; };

  const bands = (L.bands || []).filter((b) => b.p1 && b.p2).map((b) => {
    const mk = (pt, arm) => (arm ? { arm: true, ...polar(pt) } : { arm: false, ...toPlane(pt) });
    return { e1: mk(b.p1, b.p1Arm), e2: mk(b.p2, b.p2Arm), L0: b.restIn * IN, k: b.kNpm * b.count, count: b.count };
  });

  let baseMass = 0;
  for (const part of baseParts) baseMass += effectiveDensity(part.material, part.infill) * part.moments.vol;

  const s = Math.sign(L.stopDeg - L.cockDeg) || 1;
  const rig = {
    errors: [], a, e1, e2, p, toPlane, fromPlane,
    M, I: Math.max(I, 1e-7), cR: Math.hypot(cX, cY), cA: Math.atan2(cY, cX),
    bands, holder: L.holder, s, fwd: -s, // forward = -s * e1 (plane X sign)
    cock: (L.cockDeg * Math.PI) / 180, stop: (L.stopDeg * Math.PI) / 180,
    release: ((L.releaseDeg ?? 40) * Math.PI) / 180,
    mu: FRICTION[L.friction ?? 'low'] ?? 0.12,
    groundY: (L.floorY ?? 0) - p.y + MARBLE_R, baseMass,
  };
  if (L.holder === 'cup') rig.cup = polar(L.cup);
  else { rig.sl = polar(L.sling.attach); rig.slL = Math.max(0.01, (L.sling.lengthIn || 6) * IN); }
  if (Math.abs(rig.stop - rig.cock) < 1e-3) rig.errors.push('Cocked angle and stop angle are the same — the arm has nowhere to swing.');
  return rig;
}

function ptAt(e, th) {
  return e.arm ? { x: e.rho * Math.cos(e.alpha + th), y: e.rho * Math.sin(e.alpha + th), z: e.z } : e;
}

// Torque on arm (about axis, CCW in plane) from gravity on arm + bands. Also returns band potential.
function armTorque(rig, th) {
  let tau = -rig.M * G * rig.cR * Math.cos(rig.cA + th);
  for (const b of rig.bands) {
    const P1 = ptAt(b.e1, th), P2 = ptAt(b.e2, th);
    const dx = P2.x - P1.x, dy = P2.y - P1.y, dz = P2.z - P1.z;
    const Ln = Math.sqrt(dx * dx + dy * dy + dz * dz);
    if (Ln > b.L0 && Ln > 1e-9) {
      const f = (b.k * (Ln - b.L0)) / Ln;
      const fx = f * dx, fy = f * dy; // force on endpoint 1 (toward 2)
      if (b.e1.arm) tau += P1.x * fy - P1.y * fx;
      if (b.e2.arm) tau += P2.x * -fy - P2.y * -fx;
    }
  }
  return tau;
}

export function potential(rig, th) {
  let U = rig.M * G * rig.cR * Math.sin(rig.cA + th);
  for (const b of rig.bands) {
    const P1 = ptAt(b.e1, th), P2 = ptAt(b.e2, th);
    const Ln = Math.hypot(P2.x - P1.x, P2.y - P1.y, P2.z - P1.z);
    if (Ln > b.L0) U += 0.5 * b.k * (Ln - b.L0) ** 2;
  }
  return U;
}

export function bandLengths(rig, th) {
  return rig.bands.map((b) => {
    const P1 = ptAt(b.e1, th), P2 = ptAt(b.e2, th);
    return Math.hypot(P2.x - P1.x, P2.y - P1.y, P2.z - P1.z);
  });
}

function frictionApply(tau, om, fr) {
  if (Math.abs(om) > 1e-3) return tau - Math.sign(om) * fr;
  if (Math.abs(tau) <= fr) return 0;
  return tau - Math.sign(tau) * fr;
}

// Simulate the launch. Returns frames (every 1 ms) and release state in model space.
export function simulateLaunch(rig, opts = {}) {
  const m = MARBLE_M;
  const sling = rig.holder === 'sling';
  const dt = sling ? 1 / 8000 : 1 / 4000;
  const recEvery = sling ? 8 : 4; // 1 ms
  const tMax = 2.5, tAfter = 1.4;
  const e = 0.3; // stop bounce
  const kG = 3000, cG = 2 * Math.sqrt(kG * m) * 0.7;
  const frames = [];
  let th = rig.cock, om = 0, ph = 0, oph = 0;
  let mass = m; // marble mass while attached (sling: pouch afterwards)
  let released = false, rel = null, fizzle = false, hitStop = false;
  let t = 0, step = 0, peakOm = 0, prevElev = null, tRel = 0;
  const fr = (mm) => rig.mu * (rig.M + mm) * G * AXLE_R;

  if (sling) {
    const tip = ptAt({ arm: true, ...rig.sl }, th);
    const Ls = rig.slL;
    let y = tip.y - Ls;
    if (y < rig.groundY) {
      const sn = Math.max(-1, Math.min(1, (rig.groundY - tip.y) / Ls));
      const cs = Math.sqrt(1 - sn * sn) * rig.fwd;
      ph = Math.atan2(sn, cs);
    } else ph = -Math.PI / 2;
  }

  function derivCup(th, om, attached) {
    const mm = attached ? m : 0;
    let tau = armTorque(rig, th);
    let I = rig.I;
    if (mm) { tau += -mm * G * rig.cup.rho * Math.cos(rig.cup.alpha + th); I += mm * rig.cup.rho ** 2; }
    tau = frictionApply(tau, om, fr(mm));
    return tau / I;
  }

  function derivSling(th, om, ph, oph, mm) {
    const r = rig.sl.rho, b = rig.sl.alpha + th, Ls = rig.slL;
    const cb = Math.cos(b), sb = Math.sin(b), cp = Math.cos(ph), sp = Math.sin(ph);
    const x = r * cb + Ls * cp, y = r * sb + Ls * sp;
    const vx = -r * sb * om - Ls * sp * oph, vy = r * cb * om + Ls * cp * oph;
    let Fx = 0, Fy = 0;
    if (y < rig.groundY) { Fy = kG * (rig.groundY - y) - cG * vy; if (Fy < 0) Fy = 0; Fx = -0.02 * vx; }
    let Q1 = armTorque(rig, th) + Fx * (-r * sb) + Fy * (r * cb);
    Q1 = frictionApply(Q1, om, fr(mm));
    const Q2 = Fx * (-Ls * sp) + Fy * (Ls * cp);
    const cbp = Math.cos(b - ph), sbp = Math.sin(b - ph);
    const M11 = rig.I + mm * r * r, M12 = mm * r * Ls * cbp, M22 = mm * Ls * Ls;
    const r1 = Q1 - mm * G * r * cb - mm * r * Ls * sbp * oph * oph;
    const r2 = Q2 - mm * G * Ls * cp + mm * r * Ls * sbp * om * om;
    const det = M11 * M22 - M12 * M12;
    return [(r1 * M22 - M12 * r2) / det, (M11 * r2 - M12 * r1) / det, x, y, vx, vy];
  }

  const marblePlane = () => {
    if (sling) {
      const r = rig.sl.rho, b = rig.sl.alpha + th;
      return {
        x: r * Math.cos(b) + rig.slL * Math.cos(ph), y: r * Math.sin(b) + rig.slL * Math.sin(ph), z: rig.sl.z,
        vx: -r * Math.sin(b) * om - rig.slL * Math.sin(ph) * oph, vy: r * Math.cos(b) * om + rig.slL * Math.cos(ph) * oph,
      };
    }
    const c = rig.cup, b = c.alpha + th;
    return { x: c.rho * Math.cos(b), y: c.rho * Math.sin(b), z: c.z, vx: -c.rho * Math.sin(b) * om, vy: c.rho * Math.cos(b) * om };
  };

  const doRelease = (why) => {
    const mp = marblePlane();
    released = true; tRel = t;
    rel = { t, why, plane: mp, th, om };
    if (sling) mass = 0.0008; // empty pouch keeps swinging
  };

  const U0 = potential(rig, rig.cock);
  while (true) {
    if (step % recEvery === 0) {
      const mp = marblePlane();
      frames.push(t, th, ph, mp.x, mp.y);
    }
    if (released && t - tRel > tAfter) break;
    if (!released && t > tMax) { fizzle = true; doRelease('timeout'); }
    // RK4
    if (sling) {
      const f = (a, b, c, d) => derivSling(a, b, c, d, mass);
      const k1 = f(th, om, ph, oph);
      const k2 = f(th + 0.5 * dt * om, om + 0.5 * dt * k1[0], ph + 0.5 * dt * oph, oph + 0.5 * dt * k1[1]);
      const k3 = f(th + 0.5 * dt * (om + 0.5 * dt * k1[0]), om + 0.5 * dt * k2[0], ph + 0.5 * dt * (oph + 0.5 * dt * k1[1]), oph + 0.5 * dt * k2[1]);
      const k4 = f(th + dt * (om + 0.5 * dt * k2[0]), om + dt * k3[0], ph + dt * (oph + 0.5 * dt * k2[1]), oph + dt * k3[1]);
      // classical RK4 on (th,om,ph,oph)
      const dth = (om + 2 * (om + 0.5 * dt * k1[0]) + 2 * (om + 0.5 * dt * k2[0]) + (om + dt * k3[0])) / 6;
      const dph = (oph + 2 * (oph + 0.5 * dt * k1[1]) + 2 * (oph + 0.5 * dt * k2[1]) + (oph + dt * k3[1])) / 6;
      th += dt * dth; ph += dt * dph;
      om += (dt * (k1[0] + 2 * k2[0] + 2 * k3[0] + k4[0])) / 6;
      oph += (dt * (k1[1] + 2 * k2[1] + 2 * k3[1] + k4[1])) / 6;
    } else {
      const att = !released;
      const k1v = derivCup(th, om, att);
      const k2v = derivCup(th + 0.5 * dt * om, om + 0.5 * dt * k1v, att);
      const k3v = derivCup(th + 0.5 * dt * (om + 0.5 * dt * k1v), om + 0.5 * dt * k2v, att);
      const k4v = derivCup(th + dt * (om + 0.5 * dt * k2v), om + dt * k3v, att);
      const newOm = om + (dt * (k1v + 2 * k2v + 2 * k3v + k4v)) / 6;
      th += (dt * (om + 2 * (om + 0.5 * dt * k1v) + 2 * (om + 0.5 * dt * k2v) + (om + dt * k3v))) / 6;
      const acc = (newOm - om) / dt;
      om = newOm;
      // Open cup: the marble leaves as soon as the arm starts slowing down
      if (!released && rig.s * om > 1 && rig.s * acc < 0 && Math.abs(th - rig.cock) > 0.05) doRelease('arm slowed');
    }
    t += dt; step++;
    peakOm = Math.max(peakOm, Math.abs(om));
    // stop bar
    if ((th - rig.stop) * rig.s >= 0) {
      if (!released && !sling) { th = rig.stop; doRelease('hit stop'); }
      th = rig.stop; if (om * rig.s > 0) om = -e * om; hitStop = true;
    }
    // don't swing back past the cocked rest
    if ((th - rig.cock) * rig.s < 0) { th = rig.cock; if (om * rig.s < 0) om = -e * om; }
    if (sling && !released) {
      const mp = marblePlane();
      const vf = mp.vx * rig.fwd;
      const elev = Math.atan2(mp.vy, vf);
      if (prevElev !== null && vf > 0.3 && mp.y > rig.groundY + 0.003 && elev <= rig.release && prevElev > rig.release) doRelease('pin');
      prevElev = elev;
    }
  }

  const mp = rel.plane;
  const pos = rig.fromPlane(mp.x, mp.y, mp.z);
  const vel = new THREE.Vector3().addScaledVector(rig.e1, mp.vx).addScaledVector(rig.e2, mp.vy);
  const speed = vel.length();
  const vf = mp.vx * rig.fwd;
  const angle = Math.atan2(mp.vy, vf);
  const released_from = U0 - potential(rig, rel.th);
  const marbleGain = 0.5 * m * speed * speed + m * G * (mp.y - (sling ? rig.groundY - MARBLE_R * 0 : marblePlaneAt(rig, rig.cock).y));
  return {
    frames: new Float32Array(frames), stride: 5, releaseT: rel.t, why: rel.why, fizzle,
    pos, vel, speed, angle, hitStop,
    stats: {
      storedJ: Math.max(0, U0 - Math.min(potential(rig, rig.stop), U0)),
      usedJ: released_from, marbleJ: 0.5 * m * speed * speed,
      efficiency: released_from > 1e-6 ? Math.max(0, Math.min(1, marbleGain / released_from)) : 0,
      peakOm, armMass: rig.M, armI: rig.I,
    },
  };
}

function marblePlaneAt(rig, th) {
  const c = rig.cup; const b = c.alpha + th;
  return { x: c.rho * Math.cos(b), y: c.rho * Math.sin(b) };
}

// Analytic flight with quadratic drag (used for previews / tests)
export function flightRange(pos, vel, groundY = MARBLE_R) {
  const k = (0.5 * 1.2 * 0.47 * Math.PI * MARBLE_R ** 2) / MARBLE_M;
  let x = pos.x, y = pos.y, z = pos.z, vx = vel.x, vy = vel.y, vz = vel.z, t = 0, maxY = y;
  const dt = 1 / 2000;
  while (t < 10) {
    const v = Math.hypot(vx, vy, vz);
    vx -= k * v * vx * dt; vy -= (G + k * v * vy) * dt; vz -= k * v * vz * dt;
    const py = y;
    x += vx * dt; y += vy * dt; z += vz * dt; t += dt; maxY = Math.max(maxY, y);
    if (y <= groundY && vy < 0) { const f = (py - groundY) / (py - y); x -= vx * dt * (1 - f); z -= vz * dt * (1 - f); break; }
  }
  return { x, z, t, maxY };
}
