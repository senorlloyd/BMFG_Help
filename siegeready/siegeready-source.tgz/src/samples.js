// Sample launchers built as separate "parts" in model space (meters, Y up), the same shape
// an Onshape GLB export arrives in after import. Each comes pre-rigged.
import * as THREE from 'three';

const IN = 0.0254;

function box(x0, x1, y0, y1, z0, z1) {
  const g = new THREE.BoxGeometry(x1 - x0, y1 - y0, z1 - z0);
  g.translate((x0 + x1) / 2, (y0 + y1) / 2, (z0 + z1) / 2);
  return g;
}
function plate(points, z0, z1, hole) {
  const sh = new THREE.Shape(points.map(([x, y]) => new THREE.Vector2(x, y)));
  if (hole) sh.holes.push(new THREE.Path(hole.map(([x, y]) => new THREE.Vector2(x, y))));
  const g = new THREE.ExtrudeGeometry(sh, { depth: z1 - z0, bevelEnabled: false });
  g.translate(0, 0, z0);
  return g;
}
function rodZ(x, y, r, z0, z1) {
  const g = new THREE.CylinderGeometry(r, r, z1 - z0, 20);
  g.rotateX(Math.PI / 2);
  g.translate(x, y, (z0 + z1) / 2);
  return g;
}
// place a geometry built in arm-local coords (X along arm, pivot at origin) at angle deg about Z
function armPlace(g, pivot, deg) {
  g.applyMatrix4(new THREE.Matrix4().makeRotationZ((deg * Math.PI) / 180));
  g.translate(pivot.x, pivot.y, 0);
  return g;
}
function cupGeom(rOut, rIn, h, floor) {
  const pts = [
    new THREE.Vector2(0, 0), new THREE.Vector2(rOut, 0), new THREE.Vector2(rOut, h),
    new THREE.Vector2(rIn, h), new THREE.Vector2(rIn, floor), new THREE.Vector2(0, floor),
  ];
  return new THREE.LatheGeometry(pts, 28);
}
const armPt = (pivot, deg, along, off = 0) => {
  const a = (deg * Math.PI) / 180;
  return new THREE.Vector3(
    pivot.x + Math.cos(a) * along + Math.sin(a) * off,
    pivot.y + Math.sin(a) * along - Math.cos(a) * off,
    0,
  );
};

export function sampleCatapult() {
  const P = new THREE.Vector3(0.06, 0.04, 0);
  const REST = 135; // arm angle in the CAD (at-rest) pose, resting on the stop bar
  const t = 0.5 * IN, w = 0.75 * IN;
  const parts = [];
  const add = (name, geom, material, role, infill) => parts.push({ name, geom, material, role, infill });

  add('Base Plate', box(-0.15, 0.15, 0, t, -3 * IN, 3 * IN), 'plywood', 'base');
  const up = [[-0.02, t], [0.15, t], [0.145, 0.19], [0.1, 0.19], [-0.015, 0.15]];
  const win = [[0.03, 0.075], [0.125, 0.035], [0.125, 0.15], [0.09, 0.165], [0.03, 0.125]];
  add('Side Upright L', plate(up, 0.016, 0.016 + t, win), 'plywood', 'base');
  add('Side Upright R', plate(up, -0.016 - t, -0.016, win), 'plywood', 'base');
  add('Axle 1/4in', rodZ(P.x, P.y, 0.125 * IN, -0.03, 0.03), 'steel', 'base');
  const nrm = new THREE.Vector2(Math.sin((REST * Math.PI) / 180), -Math.cos((REST * Math.PI) / 180));
  const stopC = armPt(P, REST, 0.085, t / 2 + 0.0064);
  add('Stop Bar Dowel', rodZ(stopC.x, stopC.y, 0.0064, -0.0285, 0.0285), 'pine', 'base');
  add('Band Hook Dowel', rodZ(0.13, 0.17, 0.005, -0.0285, 0.0285), 'pine', 'base');

  add('Throwing Arm', armPlace(box(-0.02, 0.2, -t / 2, t / 2, -w / 2, w / 2), P, REST), 'plywood', 'arm');
  // cup: lathe axis (+Y) must point along the arm's "up when cocked" normal
  const cup = cupGeom(0.014, 0.011, 0.012, 0.003);
  const along = 0.185;
  const upLocal = new THREE.Vector3(0, -1, 0); // arm-local normal on the cocked-up side (CW of arm dir)
  cup.applyMatrix4(new THREE.Matrix4().makeRotationFromQuaternion(new THREE.Quaternion().setFromUnitVectors(new THREE.Vector3(0, 1, 0), upLocal)));
  cup.translate(along, -t / 2, 0);
  add('Marble Cup (PLA)', armPlace(cup, P, REST), 'pla', 'arm', 25);

  // marble centre: cup floor + radius, on the -Y (arm-local) side
  const marble = armPt(P, REST, along, t / 2 + 0.003 + 0.008);
  const hookArm = armPt(P, REST, 0.0635, 0);
  void nrm;
  return {
    name: 'Sample: Rubber-Band Catapult',
    parts,
    rig: {
      pivot: P.clone(), axis: 'z', holder: 'cup', cup: marble,
      sling: { attach: null, lengthIn: 6 },
      bands: [{ p1: new THREE.Vector3(0.13, 0.17, 0), p1Arm: false, p2: hookArm, p2Arm: true, count: 2, restIn: 3.5, kNpm: 80 }],
      cockDeg: 45, stopDeg: 0, releaseDeg: 40, friction: 'low', floorY: t,
    },
  };
}

export function sampleTrebuchet() {
  const P = new THREE.Vector3(0.03, 0.2, 0);
  const REST = 215; // cocked: long arm down at the back
  const t = 0.5 * IN, w = 0.75 * IN;
  const parts = [];
  const add = (name, geom, material, role, infill) => parts.push({ name, geom, material, role, infill });
  add('Base Plate', box(-0.15, 0.15, 0, t, -3 * IN, 3 * IN), 'plywood', 'base');
  const tri = [[-0.14, t], [0.14, t], [0.045, 0.215], [0.015, 0.215]];
  const win = [[-0.09, 0.03], [0.09, 0.03], [0.03, 0.17]];
  add('A-Frame L', plate(tri, 0.016, 0.016 + t, win), 'plywood', 'base');
  add('A-Frame R', plate(tri, -0.016 - t, -0.016, win), 'plywood', 'base');
  add('Cross Brace', box(-0.02, 0.08, 0.06, 0.06 + t, -0.0285, 0.0285), 'plywood', 'base');
  add('Axle 1/4in', rodZ(P.x, P.y, 0.125 * IN, -0.03, 0.03), 'steel', 'base');
  add('Throwing Arm', armPlace(box(-0.07, 0.215, -t / 2, t / 2, -w / 2, w / 2), P, REST), 'plywood', 'arm');
  add('Counterweight Box', armPlace(box(-0.09, -0.05, -0.034, 0.006, -0.024, 0.024), P, REST), 'steel', 'arm');
  const hook = new THREE.CylinderGeometry(0.003, 0.003, 0.018, 12);
  hook.rotateZ(Math.PI / 2); hook.translate(0.219, 0, 0);
  add('Release Pin (PLA)', armPlace(hook, P, REST), 'pla', 'arm', 100);
  return {
    name: 'Sample: Counterweight Trebuchet',
    parts,
    rig: {
      pivot: P.clone(), axis: 'z', holder: 'sling', cup: null,
      sling: { attach: armPt(P, REST, 0.219, 0), lengthIn: 6.5 },
      bands: [], cockDeg: 0, stopDeg: -160, releaseDeg: 40, friction: 'low', floorY: t,
    },
  };
}
