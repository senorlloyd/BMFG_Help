const { chromium } = require('playwright');
(async () => {
const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const p = await b.newPage({ viewport: { width: 900, height: 600 } });
p.on('console', m => console.log('console', m.type(), m.text().slice(0,200)));
p.on('pageerror', e => console.log('PAGEERR ' + e.message));
await p.goto('file://' + process.cwd() + '/dist/index.html');
await p.waitForFunction(() => !document.querySelector('#loading'), null, { timeout: 60000 });
const t = await p.evaluate(() => new Promise(r => { let n = 0; const t0 = performance.now(); function f(){ n++; if (n < 5) requestAnimationFrame(f); else r((performance.now()-t0)/5); } requestAnimationFrame(f); }));
console.log('ms/frame', t);
await b.close();
})();
