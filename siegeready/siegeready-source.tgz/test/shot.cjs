const { chromium } = require('playwright');
(async () => {
const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const p = await b.newPage({ viewport: { width: 1280, height: 780 } });
const errs = [];
p.on('console', m => { if (m.type() === 'error' || m.type()==='warning') errs.push(m.type()+': '+m.text()); });
p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
await p.goto('file://' + process.cwd() + '/dist/index.html');
await p.waitForFunction(() => !document.querySelector('#loading'), null, { timeout: 60000 });
await p.waitForTimeout(1500);
await p.screenshot({ path: '/tmp/s1_build.png', timeout: 120000 });
await p.evaluate(() => window.__siege.setTab('rig'));
await p.waitForTimeout(1200);
await p.screenshot({ path: '/tmp/s2_rig.png', timeout: 120000 });
await p.evaluate(() => window.__siege.setTab('launch'));
await p.waitForTimeout(1500);
await p.screenshot({ path: '/tmp/s3_field.png', timeout: 120000 });
await p.evaluate(() => window.__siege.launch());
for (const [i, ms] of [[4, 250], [5, 900], [6, 1500], [7, 2500], [8, 4000]]) { await p.waitForTimeout(ms - (i>4? [0,0,0,0,0,250,900,1500,2500][i]:0)); await p.screenshot({ path: `/tmp/s${i}.png`, timeout: 120000 }); }
const st = await p.evaluate(() => { const s = window.__siege.S; return { phase: s.phase, land: s.shot && s.shot.land, hit: s.shot && s.shot.hit, log: s.log.slice(-1) }; });
console.log(JSON.stringify(st));
console.log(errs.slice(0, 20).join('\n'));
await b.close();
})();
