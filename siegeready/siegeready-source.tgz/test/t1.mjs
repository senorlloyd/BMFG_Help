import * as THREE from 'three';
import { geomMoments, buildRig, simulateLaunch, flightRange, effectiveDensity } from '../src/physics.js';
import { sampleCatapult, sampleTrebuchet } from '../src/samples.js';
// sanity: unit cube
const c = geomMoments([new THREE.BoxGeometry(1,2,3).translate(1,0,0)]);
console.log('box vol', c.vol.toFixed(4), c.com.toArray().map(v=>v.toFixed(3)), c.ok);
for (const S of [sampleCatapult(), sampleTrebuchet()]) {
  const parts = S.parts.map(p => ({...p, geoms:[p.geom], moments: geomMoments([p.geom])}));
  for (const p of parts) console.log('  ', p.name.padEnd(22), (effectiveDensity(p.material,p.infill)*p.moments.vol*1000).toFixed(1)+' g', p.moments.ok);
  const L = { parts, ...S.rig };
  const rig = buildRig(L);
  console.log(S.name, rig.errors, 'M', rig.M.toFixed(3), 'I', rig.I.toExponential(3));
  for (const tweak of [0, 1]) {
    const t0 = performance.now();
    const r = simulateLaunch(rig);
    const fl = flightRange(r.pos, r.vel, 0.008);
    console.log(' release', r.why, 't', r.releaseT.toFixed(3), 'v', r.speed.toFixed(2), 'ang', (r.angle*180/Math.PI).toFixed(1), 'h', r.pos.y.toFixed(3),
      'range', (fl.x - 0.15).toFixed(2), 'm', 'eff', (r.stats.efficiency*100).toFixed(0)+'%', 'stored', r.stats.storedJ.toFixed(3), 'ms', (performance.now()-t0).toFixed(1), 'frames', r.frames.length/5);
  }
}
