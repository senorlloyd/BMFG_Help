import { geomMoments, buildRig, simulateLaunch, MARBLE_M, G, potential } from '../src/physics.js';
import { sampleCatapult, sampleTrebuchet } from '../src/samples.js';
for (const S of [sampleCatapult(), sampleTrebuchet()]) {
  const parts = S.parts.map(p => ({...p, moments: geomMoments([p.geom])}));
  const rig = buildRig({ parts, ...S.rig, friction:'none' });
  // energy check: run with huge time, compare KE vs PE drop at release
  const r = simulateLaunch(rig);
  const f = r.frames, st=5; let i = Math.round(r.releaseT*1000);
  const th1=f[i*st+1], th0=f[(i-1)*st+1], om=(th1-th0)/0.001;
  const ph1=f[i*st+2], ph0=f[(i-1)*st+2], oph=(ph1-ph0)/0.001;
  const armKE = 0.5*rig.I*om*om, mKE = 0.5*MARBLE_M*r.speed**2;
  const dU = potential(rig, rig.cock) - potential(rig, th1);
  const my0 = S.rig.holder==='cup' ? rig.cup.rho*Math.sin(rig.cup.alpha+rig.cock) : f[4];
  const mPE = MARBLE_M*G*(r.pos.y - rig.p.y - my0);
  console.log(S.name, 'dU', dU.toFixed(4), 'armKE+marble', (armKE+mKE+mPE).toFixed(4), r.why);
}
