const { chromium } = require('playwright');
(async () => {
const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const p = await b.newPage({ viewport: { width: 1280, height: 780 } });
const errs = [];
p.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0,300)); });
p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
await p.goto('file://' + process.cwd() + '/dist/index.html');
await p.waitForFunction(() => !document.querySelector('#loading'), null, { timeout: 60000 });
const r = await p.evaluate(async () => {
  const W = window.__siege, out = {};
  W.setTab('launch');
  // siege determinism
  const runs = [];
  for (let k = 0; k < 2; k++) {
    if (k === 0) W.launch(); else W.replay();
    W.skipShot();
    const sc = W.scoreCastle();
    runs.push({ land: W.S.shot.land.x.toFixed(5), z: W.S.shot.land.z.toFixed(5), hit: W.S.shot.hit, pts: sc.points, blocks: sc.blocks, burned: W.S.shot.burned||0 });
  }
  out.siege = runs;
  // second shot in round continues
  W.launch(); W.skipShot(); out.shot2 = { pts: W.scoreCastle().points, used: W.S.round.used };
  // distance mode trebuchet
  document.querySelector('[data-mode="distance"]').click();
  W.loadLauncher(W.sampleTrebuchet());
  W.setTab('launch');
  const d = [];
  for (let k = 0; k < 3; k++) { W.launch(); W.skipShot(); d.push(W.S.shot.land.x.toFixed(5)); }
  out.treb = d;
  out.log = W.S.log.length;
  return out;
});
console.log(JSON.stringify(r, null, 1));
// screenshot results of trebuchet with a real-time launch
await p.evaluate(() => { const W = window.__siege; W.launch(); });
await p.waitForTimeout(9000);
await p.screenshot({ path: '/tmp/t3_res.png', timeout: 120000 });
await p.evaluate(() => window.__siege.setTab('rig'));
await p.waitForTimeout(2500);
await p.screenshot({ path: '/tmp/t3_rig.png', timeout: 120000 });
console.log('errors:', errs.slice(0,10));
await b.close();
})();
