const { chromium } = require('playwright');
(async () => {
const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const p = await b.newPage({ viewport: { width: 1280, height: 780 } });
const errs = [];
p.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0,300)); });
p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
await p.goto('file://' + process.cwd() + '/dist/index.html');
await p.waitForFunction(() => !document.querySelector('#loading'), null, { timeout: 60000 });
// export both samples as GLB, save to disk
for (const nm of ['Catapult', 'Trebuchet']) {
  const b64 = await p.evaluate(async (nm) => { const W = window.__siege; W.loadLauncher(nm === 'Catapult' ? W.sampleCatapult() : W.sampleTrebuchet()); const buf = await W.exportGLB(); let s=''; const u=new Uint8Array(buf); for (let i=0;i<u.length;i++) s+=String.fromCharCode(u[i]); return btoa(s); }, nm);
  require('fs').writeFileSync(`/tmp/Sample_${nm}.glb`, Buffer.from(b64, 'base64'));
}
// import the catapult GLB through the real file input
await p.setInputFiles('#file', '/tmp/Sample_Catapult.glb');
await p.waitForTimeout(1500);
const imp = await p.evaluate(() => { const L = window.__siege.S.L; return { name: L.name, n: L.parts.length, parts: L.parts.map(p => [p.name, p.role, p.material, +(p.moments.vol*1e6).toFixed(2)]), axis: L.axis, pivot: !!L.pivot, errors: window.__siege.S.rig.errors }; });
console.log(JSON.stringify(imp));
// rig it through the data model like a student would (roles + picks)
const res = await p.evaluate(() => {
  const W = window.__siege, S = W.S, L = S.L;
  const ref = W.sampleCatapult();
  L.parts.forEach((p, i) => { p.role = ref.parts[i].role; p.material = ref.parts[i].material; p.infill = ref.parts[i].infill ?? 20; });
  Object.assign(L, { pivot: ref.rig.pivot, cup: ref.rig.cup, bands: ref.rig.bands, cockDeg: 45, stopDeg: 0 });
  // the imported model is re-centred: shift rig points by the same offset as geometry
  return 'ok';
});
await p.evaluate(() => window.__siege.setTab('rig'));
await p.waitForTimeout(3000);
await p.screenshot({ path: '/tmp/t4_import_rig.png', timeout: 120000 });
// target mode screenshot
await p.evaluate(() => { const W = window.__siege; W.loadLauncher(W.sampleCatapult()); W.setTab('launch'); document.querySelector('[data-mode="target"]').click(); W.launch(); W.skipShot(); });
await p.waitForTimeout(2500);
await p.screenshot({ path: '/tmp/t4_target.png', timeout: 120000 });
// siege fortress: 3 shots score progression
const sg = await p.evaluate(() => { const W = window.__siege; document.querySelector('[data-mode="siege"]').click(); document.querySelector('#segCastle [data-v="fortress"]').click();
  const o = []; for (let i = 0; i < 3; i++) { W.launch(); W.skipShot(); const s = W.scoreCastle(); o.push([s.points, s.blocks, s.total, W.S.shot.burned||0, s.flag]); } return o; });
console.log('fortress', JSON.stringify(sg));
await p.waitForTimeout(2000);
await p.screenshot({ path: '/tmp/t4_siege.png', timeout: 120000 });
console.log('errors:', errs.slice(0,10));
await b.close();
})();
