const { chromium } = require('playwright');
(async () => {
const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const p = await b.newPage({ viewport: { width: 1100, height: 680 } });
const errs = [];
p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
p.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0,300)); });
await p.goto('file://' + process.cwd() + '/dist/index.html');
await p.waitForFunction(() => !document.querySelector('#loading'), null, { timeout: 60000 });
await p.evaluate(() => { const W = window.__siege; W.loadLauncher(W.sampleTrebuchet()); W.setTab('launch'); });
await p.waitForTimeout(4000);
await p.evaluate(() => window.__siege.launch());
const t0 = Date.now();
for (let i = 0; i < 14; i++) { await p.screenshot({ path: `/tmp/r${String(i).padStart(2,'0')}.png`, timeout: 120000 }); const st = await p.evaluate(() => [window.__siege.S.phase, window.__siege.S.shot.t.toFixed(2)]); console.log(i, (Date.now()-t0)/1000, st.join(' ')); }
console.log(errs);
await b.close();
})();
