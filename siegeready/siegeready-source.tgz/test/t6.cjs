const { chromium } = require('playwright');
(async () => {
const b = await chromium.launch({ args: ['--use-gl=angle', '--use-angle=swiftshader', '--enable-unsafe-swiftshader'] });
const p = await b.newPage({ viewport: { width: 900, height: 600 } });
const errs = [];
p.on('pageerror', e => errs.push('PAGEERR ' + e.message));
p.on('console', m => { if (m.type() === 'error') errs.push(m.text().slice(0,300)); });
await p.goto('file://' + process.cwd() + '/dist/index.html');
await p.waitForFunction(() => !document.querySelector('#loading'), null, { timeout: 60000 });
await p.setInputFiles('#file', '/tmp/Sample_Catapult.glb');
await p.waitForTimeout(800);
await p.click('.tabs [data-tab="rig"]');
await p.waitForTimeout(800);
// set roles through the UI selects
const roles = { 'Throwing Arm': 'arm', 'Marble Cup (PLA)': 'arm' };
for (const [nm, role] of Object.entries(roles)) {
  const idx = await p.evaluate((nm) => window.__siege.S.L.parts.findIndex(p => p.name === nm), nm);
  await p.selectOption(`.part[data-id="${idx}"] select[data-k="role"]`, role);
}
const cupIdx = await p.evaluate(() => window.__siege.S.L.parts.findIndex(p => p.name.startsWith('Marble Cup')));
await p.selectOption(`.part[data-id="${cupIdx}"] select[data-k="material"]`, 'pla');
await p.waitForTimeout(1500);
const proj = async (pt) => p.evaluate((pt) => { const W = window.__siege; const THREE_V = W.camera.position.constructor; const v = new THREE_V(pt[0], pt[1], pt[2]); v.project(W.camera); const c = document.querySelector('#c').getBoundingClientRect(); return [(v.x + 1) / 2 * c.width, (1 - v.y) / 2 * c.height]; }, pt);
// pivot: click on the axle end (z=+0.03 face, slightly off-centre)
await p.click('#stPivot summary'); await p.click('[data-pick="pivot"]');
let xy = await proj([0.06, 0.04, 0.03]); await p.mouse.click(xy[0], xy[1]);
await p.waitForTimeout(300);
// cup: click inside the cup bottom (cocked view shows arm at 45)
await p.click('[data-pick="cup"]');
const cupPt = await p.evaluate(() => { const W = window.__siege; const r = W.sampleCatapult().rig.cup; return [r.x, r.y, r.z]; });
// marble spot is at preview angle (cocked 45°): compute its world position
xy = await p.evaluate((c) => { const W = window.__siege; const L = W.S.L; const V = W.camera.position.constructor; const v = new V(c[0], c[1], c[2]);
  const q = new (W.camera.quaternion.constructor)().setFromAxisAngle(new V(0,0,1), L.cockDeg*Math.PI/180); v.sub(L.pivot).applyQuaternion(q).add(L.pivot); v.y -= 0.007; v.project(W.camera); const cr = document.querySelector('#c').getBoundingClientRect(); return [(v.x + 1) / 2 * cr.width, (1 - v.y) / 2 * cr.height]; }, cupPt);
await p.mouse.click(xy[0], xy[1]);
await p.waitForTimeout(300);
const st = await p.evaluate(() => { const L = window.__siege.S.L; const f = (v) => v && [v.x, v.y, v.z].map(n => +n.toFixed(4)); return { pivot: f(L.pivot), cup: f(L.cup), axis: L.axis, errors: window.__siege.S.rig.errors }; });
console.log(JSON.stringify(st));
await p.screenshot({ path: '/tmp/t6.png', timeout: 120000 });
console.log(errs);
await b.close();
})();
